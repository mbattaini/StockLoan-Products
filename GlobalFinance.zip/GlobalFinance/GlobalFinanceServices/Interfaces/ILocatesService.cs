﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Data;



namespace StockLoan.WebServices.LocatesService
{
    [ServiceContract]
    public interface ILocatesService
    {
        [OperationContract]
        byte[] TradingGroupsGet(string tradeDate, short utcOffset);

        [OperationContract]
        string LocateListSubmit(string clientId, string groupCode, string clientComment, string list);

        [OperationContract]
        byte[] InventoryGet(string groupCode, string secId, short utcOffset);

        [OperationContract]
        byte[] LocateItemGet(string groupCode, string locateId, short utcOffset);

        [OperationContract]
        byte[] LocatesGet(string tradeDate, string groupCode, string clientId, short utcOffset, string status);

        [OperationContract]
        byte[] LocateSummaryGet(string tradeDate, string secId);

        [OperationContract]
        byte[] LocateGroupCodeSummaryGet(string tradeDate);
    } 
}
