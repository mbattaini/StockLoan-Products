﻿
using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("Golbal Finance Service")]
[assembly: AssemblyDescription("Harness for testing the LoanStar WorldWide Data Service.")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyCompany("StockLoan, LLC")]
[assembly: AssemblyProduct("StockLoan")]
[assembly: AssemblyCopyright("Copyright 2010 StockLoan, LLC.  All rights reserved.")]
[assembly: AssemblyTrademark("StockLoan and LoanStar are trademarks of StockLoan, LLC.")]
[assembly: AssemblyCulture("")]

[assembly: AssemblyVersion("1.0.8")]
[assembly: AssemblyFileVersion("1.0.8")]

[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
[assembly: AssemblyKeyName("")]
