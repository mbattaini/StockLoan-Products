﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using C1.Silverlight.Data;

using StockLoan_LocatesClient.ServiceLocates;

namespace StockLoan_LocatesClient
{
	public partial class LocatesGridControl : UserControl
	{
        private LocatesServiceClient lsClient;

		public LocatesGridControl()
		{
			// Required to initialize variables
			InitializeComponent();

            lsClient = new LocatesServiceClient();

            lsClient.LocatesGetCompleted += new EventHandler<LocatesGetCompletedEventArgs>(lsClient_LocatesGetCompleted);
            CustomEvents.GroupCodeFilterChanged += new EventHandler<GroupCodeFilterEventArgs>(CustomEvents_GroupCodeFilterChanged);
                
        }

        void CustomEvents_GroupCodeFilterChanged(object sender, GroupCodeFilterEventArgs e)
        {
            if ((bool)CheckBoxFilterGroupCode.IsChecked)
            {
                LocatesGrid.IsLoading = true;
                lsClient.LocatesGetAsync(BizDatePicker.DateTime.Value.ToString("yyyy-MM-dd"), e.GroupCode, "", 0, "");
            }
        }

        void lsClient_LocatesGetCompleted(object sender, LocatesGetCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                return;
            }

            try
            {
                LocatesGrid.ItemsSource = Functions.ConvertToDataTable(e.Result, 0).DefaultView;
                LocatesGrid.IsLoading = false;
                LocatesGrid.SelectedIndex = 1;
            }
            catch 
            {
                LocatesGrid.IsLoading = false;
            }
        }

        private void BizDatePicker_DateTimeChanged(object sender, C1.Silverlight.DateTimeEditors.NullablePropertyChangedEventArgs<DateTime> e)
        {
            if (!LocatesGrid.IsLoading)
            {
                UserInformation.CurrentDate = BizDatePicker.DateTime.Value.ToString("yyyy-MM-dd");
                lsClient.LocatesGetAsync(BizDatePicker.DateTime.Value.ToString("yyyy-MM-dd"), "", "", 0, "");
                LocatesGrid.IsLoading = true;
            }
        }

        private void LocatesGrid_SelectionChanged(object sender, C1.Silverlight.DataGrid.DataGridSelectionChangedEventArgs e)
        {
            if (!LocatesGrid.IsLoading)
            {
                UserInformation.GlobalFilterSecId = LocatesGrid[LocatesGrid.SelectedIndex, 1].Text;
                UserInformation.GroupCode = LocatesGrid[LocatesGrid.SelectedIndex, 5].Text;
            }
        }

        private void ButtonCheckSelected_Click(object sender, System.Windows.RoutedEventArgs e)
        {
        	for (int index = 0; index  < LocatesGrid.Selection.SelectedRows.Count; index ++)
			{				
			//	LocatesGrid.Columns["IsFill"]
			}
        }
    }
}