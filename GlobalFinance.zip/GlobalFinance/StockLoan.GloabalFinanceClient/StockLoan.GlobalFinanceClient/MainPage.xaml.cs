﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace StockLoan_LocatesClient
{
	public partial class MainPage : UserControl
	{
		public MainPage()
		{
			// Required to initialize variables
			InitializeComponent();
		
			ClientWindow clntWindow = new ClientWindow();
			clntWindow.Content = new LoginControl();
			clntWindow.Show();
			clntWindow.CenterOnScreen();
		}

		private void LocatesButton_Click(object sender, System.Windows.RoutedEventArgs e)
		{
			ClientItem _item1 = new ClientItem();
            _item1.Load("Locates Grid", new LocatesGridControl());
            UpperMainDockTabControl.Items.Add(_item1.Item);
			
			ClientItem _item2 = new ClientItem();
            _item2.Load("Inventory Availability", new LocateAvailableInventoryControl());
            LowerLeftDockTabControl.Items.Add(_item2.Item);
			
			ClientItem _item3 = new ClientItem();
            _item3.Load("Locates Summary", new LocateSummaryControl());
            LowerMiddleDockTabControl.Items.Add(_item3.Item);												
			
			ClientItem _item4 = new ClientItem();
            _item4.Load("Group Code Summary", new LocateGroupCodeSummaryControl());
            LowerRightDockTabControl.Items.Add(_item4.Item);												
		}

		private void SubmitListButton_Click(object sender, System.Windows.RoutedEventArgs e)
		{
			ClientWindow clntWindow = new ClientWindow();
			clntWindow.Content = new LocateSubmitListControl();
			clntWindow.Show();
			clntWindow.CenterOnScreen();
		}
	}
}