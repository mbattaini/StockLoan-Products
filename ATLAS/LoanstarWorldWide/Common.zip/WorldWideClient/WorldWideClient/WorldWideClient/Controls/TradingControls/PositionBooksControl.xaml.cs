﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using C1.Silverlight.Data;
using C1.Silverlight.DataGrid.Filters;

using WorldWideClient.ServiceBooks;
using WorldWideClient.ServiceUserAdmin;

namespace WorldWideClient
{
	public partial class PositionBooksControl : UserControl
	{
		private BooksServiceClient bookServiceClient;
		private UserAdminServiceClient userAdminServiceClient;
		private DataTable dtBooks;
		
		public PositionBooksControl()
		{
			// Required to initialize variables
			InitializeComponent();
			
			bookServiceClient = new BooksServiceClient();
			userAdminServiceClient = new UserAdminServiceClient();

            bookServiceClient.BooksGetCompleted += new EventHandler<BooksGetCompletedEventArgs>(bookServiceClient_BooksGetCompleted);
            userAdminServiceClient.UserBookGroupsGetCompleted += new EventHandler<UserBookGroupsGetCompletedEventArgs>(userAdminServiceClient_UserBookGroupsGetCompleted);

            userAdminServiceClient.UserBookGroupsGetAsync(UserInformation.UserId, System.Reflection.MethodBase.GetCurrentMethod().ReflectedType.Name);
        }

        void userAdminServiceClient_UserBookGroupsGetCompleted(object sender, UserBookGroupsGetCompletedEventArgs e)
        {
			
            if (e.Error != null)
            {
                SystemEventWindow.Show(e.Error.Message);
                return;
            }

            DataTable dtBookGroups = Functions.ConvertToDataTable(e.Result, "UserBookGroups");

            foreach (DataRow drTemp in dtBookGroups.Rows)
            {
                BookGroupComboBox.Items.Add(drTemp["BookGroup"].ToString());
            }
        }

        void bookServiceClient_BooksGetCompleted(object sender, BooksGetCompletedEventArgs e)
        {
            BooksGrid.IsLoading = false;
			
			if (e.Error != null)
            {
                SystemEventWindow.Show(e.Error.Message);
                return;
            }

            dtBooks = Functions.ConvertToDataTable(e.Result, "Books");

           BooksGrid.ItemsSource = dtBooks.DefaultView;						
        }

        private void BookGroupComboBox_SelectedValueChanged(object sender, C1.Silverlight.PropertyChangedEventArgs<object> e)
        {
            bookServiceClient.BooksGetAsync(
                BookGroupComboBox.Text,
                "",
                UserInformation.UserId,
                UserInformation.Password,
                System.Reflection.MethodBase.GetCurrentMethod().ReflectedType.Name);
			
        }

        private void UserControl_Loaded(object sender, System.Windows.RoutedEventArgs e)
        {       				
			BooksGrid.TopRows.Clear();
			BooksGrid.TopRows.Add(new DataGridFilterRow());			
			BooksGrid.Reload(false);           
        }
	}
}