﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;


using C1.Silverlight;
using C1.Silverlight.Data;
using C1.Silverlight.DataGrid;
using C1.Silverlight.DataGrid.Filters;
using WorldWideClient.ServicePositions;

namespace WorldWideClient
{
	public partial class PositionDeskInputControl : UserControl
	{        
        private PositionsServiceClient positionsClient;

		public PositionDeskInputControl()
		{			
			InitializeComponent();

			positionsClient = new PositionsServiceClient();
            positionsClient.BoxPositionLookupGetCompleted += new EventHandler<BoxPositionLookupGetCompletedEventArgs>(positionsClient_BoxPositionLookupGetCompleted);
            CustomEvents.UserBookGroupInformationChanged += new EventHandler<UserBookGroupEventArgs>(CustomEvents_UserBookGroupInformationChanged);                       
        }

        void positionsClient_BoxPositionLookupGetCompleted(object sender, BoxPositionLookupGetCompletedEventArgs e)
        {
            InputGrid.IsLoading = false;

            if (e.Error != null)
            {
                SystemEventWindow.Show(e.Error.Message);
                return;
            }

            DataTable dtBox = Functions.ConvertToDataTable(e.Result,"Box");

            InputGrid.ItemsSource = dtBox.DefaultView;
        }

        void CustomEvents_UserBookGroupInformationChanged(object sender, UserBookGroupEventArgs e)
        {
            if (e != null)
            {
                if (e.Book.Equals(""))
				{
					BookGroupTextBox.Text = e.BookGroup;
				}
				
				if (e.BookGroup.Equals(""))
				{
                	BookTextBox.Text = e.Book;
				}
            }
        }


		private void ParseListButton_Click(object sender, System.Windows.RoutedEventArgs e)
		{
			if (!ListTextBox.Text.Equals(""))
            {
				positionsClient.BoxPositionLookupGetAsync(ListTextBox.Text, BookGroupTextBox.Text, true, UserInformation.UserId);
                InputGrid.IsLoading = true;
            }
			else
			{
				SystemEventWindow.Show("Unable to parse list.");
			}
			
		}
        
        private void BookGroupButton_Click(object sender, System.Windows.RoutedEventArgs e)
        {			
			ClientWindow clntWindow = new ClientWindow();			
			clntWindow.Content = new PositionBooksToolControl(UserInformation.UserId, "", System.Reflection.MethodBase.GetCurrentMethod().ReflectedType.Name);			
			clntWindow.Resize = false;
			clntWindow.CenterOnScreen();
			clntWindow.Show();			
        }

        private void BookButton_Click(object sender, System.Windows.RoutedEventArgs e)
        {
        	ClientWindow clntWindow = new ClientWindow();			
			clntWindow.Content = new PositionBooksToolControl(UserInformation.UserId, BookGroupTextBox.Text, System.Reflection.MethodBase.GetCurrentMethod().ReflectedType.Name);			
			clntWindow.Resize = false;
			clntWindow.CenterOnScreen();	
			clntWindow.Show();			
        }
		
		private void contextMenu_ItemClick(object sender, SourcedEventArgs e)
		{
			switch(((C1MenuItem)e.Source).Header.ToString())
			{
				case ("Paste"):
					if (System.Windows.Clipboard.ContainsText())
						ListTextBox.Text= System.Windows.Clipboard.GetText();
						break;
					
				case ("Copy"):
					System.Windows.Clipboard.SetText(ListTextBox.Text);					
					break;
					
				case ("Cut"):
					System.Windows.Clipboard.SetText(ListTextBox.Text);
					ListTextBox.Text = "";
					break;				
			}			
		}

		private void UserControl_Loaded(object sender, System.Windows.RoutedEventArgs e)
		{            
			InputGrid.TopRows.Clear();
			InputGrid.TopRows.Add(new DataGridFilterRow());			
			InputGrid.Reload(false);           
		}

		private void Radio_Checked(object sender, System.Windows.RoutedEventArgs e)
		{
			if ((bool)RadioInventory.IsChecked)
			{
				InventorySubmitButton.IsEnabled = true;
				BookGroupLookupButton.IsEnabled = false;
				BookTradesButton.IsEnabled = false;
			}
			else
			{
				InventorySubmitButton.IsEnabled = false;
				BookGroupLookupButton.IsEnabled = true;
				BookTradesButton.IsEnabled = true;
			}
		}

        private void BookDetailsButton_Click(object sender, RoutedEventArgs e)
        {
            if (!BookTextBox.Text.Equals("") && (!BookGroupTextBox.Text.Equals("")))
            {
                ClientWindow clntWindow = new ClientWindow();
                clntWindow.Content = new PositionBooksDetailControl(BookGroupTextBox.Text, BookTextBox.Text);
                clntWindow.Show();
                clntWindow.CenterOnScreen();
            }
        }
	}
}