﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using C1.Silverlight;
using C1.Silverlight.Data;
using C1.Silverlight.DataGrid;
using C1.Silverlight.DataGrid.Filters;
using WorldWideClient.ServicePositions;


namespace WorldWideClient
{
	public partial class PositionBoxSummaryControl : UserControl
	{
		private PositionsServiceClient positionsClient;
		
		public PositionBoxSummaryControl()
		{
		
			InitializeComponent();
			
			positionsClient = new PositionsServiceClient();
            positionsClient.BoxSummaryDataConfigGetCompleted += new EventHandler<BoxSummaryDataConfigGetCompletedEventArgs>(positionsClient_BoxSummaryDataConfigGetCompleted);

            positionsClient.BoxSummaryDataConfigGetAsync("2011-11-10", "0158", false, "10", UserInformation.UserId, UserInformation.Password, System.Reflection.MethodBase.GetCurrentMethod().ReflectedType.Name); 
        }

        void positionsClient_BoxSummaryDataConfigGetCompleted(object sender, BoxSummaryDataConfigGetCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                SystemEventWindow.Show(e.Error.Message);
                return;
            }

            InputGrid.ItemsSource = Functions.ConvertToDataTable(e.Result, "BoxSummary").DefaultView;
        }
	
        
    }
}