﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Xml;
using System.IO.IsolatedStorage;
using System.IO;
using System.Text;
using System.Xml.Linq;
using System.Xml.Serialization;

using System.Windows.Data;
using System.Threading;
using System.Reflection;

using C1.Silverlight.DataGrid;


namespace WorldWideClient
{
    public class Excel
    {
        public static void ExportToExcel(C1DataGrid tGrid)
        {
            var dialog = new SaveFileDialog();
            //opening Save dialogbox for user to save file 
            dialog.DefaultExt = "*.xml";
            dialog.Filter = "Excel Xml (*.xml)|*.xml|All files (*.*)|*.*";

            if (dialog.ShowDialog() == false) return;

            using (var sw = new StreamWriter(dialog.OpenFile()))
            {
                var excelContent = GetExcelFile(tGrid, true, false, true);
                excelContent.Save(sw);
            }
        }

        public static XDocument GetExcelFile(C1DataGrid dataGrid, bool generateColumnTitles, bool setRowHeight, bool setColumnWidth)
        {
            Assembly assembly = Assembly.GetExecutingAssembly();

            string excelTemplateResourcestring = "";
            try
            {
                string first = assembly.GetManifestResourceNames().First().ToString();

                excelTemplateResourcestring = assembly.GetManifestResourceNames().First((resourceName) => resourceName.ToLower().Contains(@".resources.exceltemplate.xml"));
            }
            catch { }
            XDocument xml = XDocument.Load(assembly.GetManifestResourceStream(excelTemplateResourcestring));
            var table = (from element in xml.Descendants("{urn:schemas-microsoft-com:office:spreadsheet}Worksheet")
                         where element.Attribute("{urn:schemas-microsoft-com:office:spreadsheet}Name").Value == "Sheet1"
                         select element.Element("{urn:schemas-microsoft-com:office:spreadsheet}Table")).First();

            //table settings
            table.SetAttributeValue("{urn:schemas-microsoft-com:office:spreadsheet}ExpandedColumnCount", dataGrid.Columns.Count);
            table.SetAttributeValue("{urn:schemas-microsoft-com:office:spreadsheet}ExpandedRowCount", dataGrid.Rows.Count + (generateColumnTitles ? 1 : 0));
            if (dataGrid.RowHeight.IsAbsolute && setRowHeight)
            {
                table.SetAttributeValue("{urn:schemas-microsoft-com:office:spreadsheet}DefaultRowHeight", dataGrid.RowHeight.Value);
            }

            //add the rows
            for (int i = generateColumnTitles ? -1 : 0; i < dataGrid.Rows.Count; i++)
            {
                DataGridRow row = null;
                if (i >= 0)
                {

                    row = dataGrid.Rows[i];
                }
                XElement rowElement = new XElement("{urn:schemas-microsoft-com:office:spreadsheet}Row");
                bool isFirstColumn = true;
                //add the columns
                for (int j = 0; j < dataGrid.Columns.Count; j++)
                {

                    DataGridColumn column = dataGrid.Columns[j];
                    //If is the row that contains the column titles
                    if (i == -1)
                    {
                        string columnTitle = column.GetColumnText();
                        XElement columnElement = new XElement("{urn:schemas-microsoft-com:office:spreadsheet}Column");
                        columnElement.SetAttributeValue("{urn:schemas-microsoft-com:office:spreadsheet}AutoFitWidth", column.Width.IsAbsolute ? 0 : 1);
                        if (column.Width.IsAbsolute && setColumnWidth)
                        {
                            columnElement.SetAttributeValue("{urn:schemas-microsoft-com:office:spreadsheet}Width", column.Width.Value);
                        }
                        table.Add(columnElement);
                        XElement titleElement = new XElement("{urn:schemas-microsoft-com:office:spreadsheet}Cell");
                        XElement titleDataElement = new XElement("{urn:schemas-microsoft-com:office:spreadsheet}Data", columnTitle);
                        titleDataElement.SetAttributeValue("{urn:schemas-microsoft-com:office:spreadsheet}Type", "String");
                        titleElement.Add(titleDataElement);
                        rowElement.Add(titleElement);
                    }
                    else
                    {
                        if (row.Type == DataGridRowType.Group)
                        {
                            if (isFirstColumn)
                            {
                                //output.Append(GetGroupText((DataGridGroupRow)row));
                            }
                        }
                        else
                        {
                            XElement cellElement = new XElement("{urn:schemas-microsoft-com:office:spreadsheet}Cell");
                            var cell = dataGrid[row, column];
                            if (cell != null)
                            {
                                XElement cellDataElement = new XElement("{urn:schemas-microsoft-com:office:spreadsheet}Data", cell.Text);
                                cellDataElement.SetAttributeValue("{urn:schemas-microsoft-com:office:spreadsheet}Type", GetColumnExcelType(column));
                                cellElement.Add(cellDataElement);
                            }
                            rowElement.Add(cellElement);
                        }
                    }
                    isFirstColumn = false;
                }
                table.Add(rowElement);
            }
            return xml;
        }

        private static string GetColumnExcelType(DataGridColumn column)
        {
            return "String";
        }
    }
}
