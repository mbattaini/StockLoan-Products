﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using StockLoan.DataAccess;

using StockLoan.Common;

namespace StockLoan.Business
{
    public class Positions
    {

        public static DataSet BoxPositionGet(string bizDate, string bookGroup, string secId)
        {
            DataSet dsTemp = new DataSet();

            try
            {
                if (bizDate.Equals(""))
                { 
                    throw new Exception("Biz Date is required");
                }


                dsTemp = DBPositions.BoxPositionsGet(bizDate, bookGroup, secId);
                
                return dsTemp;
            }
            catch 
            {
                throw;
            }
        }

        public static DataSet BoxPositionItemGet(string bizDate, string bookGroup, string secId)
        {
            DataSet dsTemp = new DataSet();

            try
            {
                if (bizDate.Equals(""))
                {
                    throw new Exception("Biz Date is required");
                }


                dsTemp = DBPositions.BoxPositionsGet(bizDate, bookGroup, secId);

                return dsTemp;
            }
            catch
            {
                throw;
            }
        }

        public static DataSet BoxPositionLookupGet(string boxList, string bookGroup, bool includeRates)
        {
            List list = new List(boxList);
            DataSet dsBoxItems = new DataSet();
            dsBoxItems.Tables.Add("Box");
            dsBoxItems.Tables["Box"].Columns.Add("SecId");
            dsBoxItems.Tables["Box"].Columns.Add("Quantity");
            dsBoxItems.Tables["Box"].Columns.Add("BoxQuantity");
            dsBoxItems.Tables["Box"].Columns.Add("Price");
            dsBoxItems.Tables["Box"].Columns.Add("Amount");
            dsBoxItems.Tables["Box"].Columns.Add("Rate");
            dsBoxItems.Tables["Box"].Columns.Add("Profit");
            dsBoxItems.Tables["Box"].Columns.Add("IsTrashed");
            dsBoxItems.AcceptChanges();

            if (list.Status)
            {
                ListItem listItem = new ListItem();

                for (int index = 0; index < list.Count; index++)
                {
                    listItem = list.ItemGet(index);

                    DataRow drItem = dsBoxItems.Tables["Box"].NewRow();
                    drItem["SecId"] = listItem.SecId;
                    drItem["Quantity"] = listItem.Quantity;
                    drItem["IsTrashed"] = false;
                    dsBoxItems.Tables["Box"].Rows.Add(drItem);
                }

                dsBoxItems.AcceptChanges();
            }

            if (!bookGroup.Equals(""))
            {
                DataSet dsBox;
                DataSet dsItems;
                DataSet dsRates;


                decimal amount;
                decimal rate;
                decimal margin = 1.02M;

                foreach (DataRow drItem in dsBoxItems.Tables["Box"].Rows)
                {
                    amount = -1;
                    rate = 1000;
                    dsItems = DBPositions.BoxPositionsGet(DBStandardFunctions.BizDateStrGet(bookGroup, "BIZDATE"), bookGroup, drItem["SecId"].ToString());
                    dsRates = DBInventory.InventoryRatesGet(DBStandardFunctions.BizDateStrGet(bookGroup, "BIZDATE"), bookGroup, "", drItem["SecId"].ToString(), "", "", "");

                    if (dsItems.Tables["BoxPosition"].Rows.Count > 0)
                    {

                        Console.Write(dsItems.Tables["BoxPosition"].Rows[0]["Price"].ToString() + " " + drItem["Quantity"].ToString());

                        try
                        {
                            drItem["BoxQuantity"] = long.Parse(dsItems.Tables["BoxPosition"].Rows[0]["ExDeficitSettled"].ToString());
                        }
                        catch 
                        {
                            drItem["BoxQuantity"] = 0;
                        }

                        try
                        {

                            drItem["Amount"] = float.Parse(dsItems.Tables["BoxPosition"].Rows[0]["Price"].ToString()) * long.Parse(drItem["BoxQuantity"].ToString());
                            amount = decimal.Parse(drItem["Amount"].ToString());
                        }
                        catch
                        {
                            amount = -1;
                            drItem["Amount"] = 0;
                        }
                    }
                    else
                    {
                        drItem["BoxQuantity"] = 0;
                        drItem["Amount"] = 0;
                    }


                    if (dsRates.Tables["InventoryRates"].Rows.Count > 0)
                    {
                        try
                        {
                            drItem["Rate"] = decimal.Parse(dsItems.Tables["InventoryRates"].Rows[0]["Rate"].ToString());
                            rate = decimal.Parse(drItem["Rate"].ToString());
                        }
                        catch 
                        {
                            rate = 1000;
                            drItem["Rate"] = "";
                        }
                    }
                    else
                    {
                        drItem["Rate"] = "";
                    }

                    if (amount != -1 & rate != 1000)
                    {

                        drItem["Profit"] = ((amount * margin) * (rate / 100)) / 360;
                    }
                }
             
            }

            dsBoxItems.AcceptChanges();

            return dsBoxItems;
        }
    }
}
