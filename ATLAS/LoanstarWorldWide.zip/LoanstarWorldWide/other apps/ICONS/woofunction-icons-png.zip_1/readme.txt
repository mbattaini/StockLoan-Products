WooFunction Web Icon Set

This icon set is released on the GNU General Public License.

http://wefunction.com/
http://www.woothemes.com