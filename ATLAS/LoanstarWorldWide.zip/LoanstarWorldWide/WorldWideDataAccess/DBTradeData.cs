﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

using StockLoan.Common;

namespace StockLoan.DataAccess
{
    public class DBTradeData
    {

        private static string dbCnStr = DBStandardFunctions.DbCnStr;

        public static void TradeDataContractsPurge(string bizDate, string bookGroup)
        {
            DataSet dsTradeSettings = new DataSet();
            SqlConnection dbCn = new SqlConnection(DBStandardFunctions.DbCnStr);


            try
            {
                SqlCommand dbCmd = new SqlCommand("dbo.spContractPurge", dbCn);
                dbCmd.CommandType = CommandType.StoredProcedure;
                dbCmd.CommandTimeout = int.Parse(Standard.ConfigValue("DatabaseTimeout", "300"));

                SqlParameter paramBizDate = dbCmd.Parameters.Add("@BizDate", SqlDbType.DateTime);
                paramBizDate.Value = bizDate;

                SqlParameter paramBookGroup = dbCmd.Parameters.Add("@BookGroup", SqlDbType.VarChar, 10);
                paramBookGroup.Value = bookGroup;

                dbCn.Open();
                dbCmd.ExecuteNonQuery();
                dbCn.Close();
            }
            catch
            {
                throw;
            }
            finally
            {
                if (dbCn.State != ConnectionState.Closed)
                {
                    dbCn.Close();
                }
            }
        }

        public static DataSet TradeDataSettingsGet(string bookGroup)
        {
            DataSet dsTradeSettings = new DataSet();
            SqlConnection dbCn = new SqlConnection(DBStandardFunctions.DbCnStr);


            try
            {
                SqlCommand dbCmd = new SqlCommand("dbo.spBookGroupTradeSettingsGet", dbCn);
                dbCmd.CommandType = CommandType.StoredProcedure;
                dbCmd.CommandTimeout = int.Parse(Standard.ConfigValue("DatabaseTimeout", "300"));

                if (!bookGroup.Equals(""))
                {
                    SqlParameter paramBookGroup = dbCmd.Parameters.Add("@BookGroup", SqlDbType.VarChar, 10);
                    paramBookGroup.Value = bookGroup;
                }

                SqlDataAdapter dataAdapter = new SqlDataAdapter(dbCmd);
                dataAdapter.Fill(dsTradeSettings, "BookGroups");
            }
            catch
            {
                throw;
            }

            return dsTradeSettings;
        }

        public static void TradeDataSettingSet(string bookGroup, string tradesDate, string marksDate, string recallsDate, string clientsDate)
        {            
            SqlConnection dbCn = new SqlConnection(DBStandardFunctions.DbCnStr);


            try
            {
                SqlCommand dbCmd = new SqlCommand("dbo.spBookGroupTradeSettingSet", dbCn);
                dbCmd.CommandType = CommandType.StoredProcedure;
                dbCmd.CommandTimeout = int.Parse(Standard.ConfigValue("DatabaseTimeout", "300"));

                SqlParameter paramBookGroup = dbCmd.Parameters.Add("@BookGroup", SqlDbType.VarChar, 10);
                paramBookGroup.Value = bookGroup;

                if (!tradesDate.Equals(""))
                {
                    SqlParameter paramFileNameTradesDate = dbCmd.Parameters.Add("@FileNameTradesDate", SqlDbType.DateTime);
                    paramFileNameTradesDate.Value = tradesDate;
                }

                if (!marksDate.Equals(""))
                {
                    SqlParameter paramFileNameMarksDate = dbCmd.Parameters.Add("@FileNameMarksDate", SqlDbType.DateTime);
                    paramFileNameMarksDate.Value = marksDate;
                }

                if (!recallsDate.Equals(""))
                {
                    SqlParameter paramFileNameRecallsDate = dbCmd.Parameters.Add("@FileNameRecallsDate", SqlDbType.DateTime);
                    paramFileNameRecallsDate.Value = recallsDate;
                }

                if (!clientsDate.Equals(""))
                {
                    SqlParameter paramFileNameClientsDate = dbCmd.Parameters.Add("@FileNameClientsDate", SqlDbType.DateTime);
                    paramFileNameClientsDate.Value = clientsDate;
                }

                dbCn.Open();
                dbCmd.ExecuteNonQuery();
                dbCn.Close();
            }
            catch
            {
                throw;
            }
            finally
            {
                if (dbCn.State != ConnectionState.Closed)
                {
                    dbCn.Close();
                }
            }
        }

        public static void TradeDataMarksPurge(string bizDate, string bookGroup)
        {            
            SqlConnection dbCn = new SqlConnection(DBStandardFunctions.DbCnStr);


            try
            {
                SqlCommand dbCmd = new SqlCommand("dbo.spTradeDataMarksPurge", dbCn);
                dbCmd.CommandType = CommandType.StoredProcedure;
                dbCmd.CommandTimeout = int.Parse(Standard.ConfigValue("DatabaseTimeout", "300"));

                SqlParameter paramBizDate = dbCmd.Parameters.Add("@BizDate", SqlDbType.DateTime);
                paramBizDate.Value = bizDate;

                SqlParameter paramBookGroup = dbCmd.Parameters.Add("@BookGroup", SqlDbType.VarChar, 10);
                paramBookGroup.Value = bookGroup;

                dbCn.Open();
                dbCmd.ExecuteNonQuery();
                dbCn.Close();
            }
            catch
            {
                throw;
            }
            finally
            {
                if (dbCn.State != ConnectionState.Closed)
                {
                    dbCn.Close();
                }
            }
        }

        public static void TradeDataMarkItemSet(string bizDate, string bookGroup, string contractId, string contractType, string amount)
        {
            SqlConnection dbCn = new SqlConnection(DBStandardFunctions.DbCnStr);

            try
            {
                SqlCommand dbCmd = new SqlCommand("dbo.spTradeDataMarkSet", dbCn);
                dbCmd.CommandType = CommandType.StoredProcedure;
                dbCmd.CommandTimeout = int.Parse(Standard.ConfigValue("DatabaseTimeout", "300"));

                SqlParameter paramBizDate = dbCmd.Parameters.Add("@BizDate", SqlDbType.DateTime);
                paramBizDate.Value = bizDate;
                
                SqlParameter paramBookGroup = dbCmd.Parameters.Add("@BookGroup", SqlDbType.VarChar, 10);
                paramBookGroup.Value = bookGroup;

                SqlParameter paramContractId = dbCmd.Parameters.Add("@ContractId", SqlDbType.VarChar, 16);
                paramContractId.Value = contractId;
                    
                SqlParameter paramContractType = dbCmd.Parameters.Add("@ContractType", SqlDbType.VarChar, 1);
                paramContractType.Value = contractType;
                    
                SqlParameter paramAmount = dbCmd.Parameters.Add("@Amount", SqlDbType.Money);
                paramAmount.Value = amount;
                    
                dbCn.Open();
                dbCmd.ExecuteNonQuery();
                dbCn.Close();
            }
            catch
            {
                throw;
            }
            finally
            {
                if (dbCn.State != ConnectionState.Closed)
                {
                    dbCn.Close();
                }
            }
        }

        public static void TradeDataContractsBizDateRoll(string bizDatePrior, string bizDate, string bookGroup)
        {
            DataSet dsTradeSettings = new DataSet();
            SqlConnection dbCn = new SqlConnection(DBStandardFunctions.DbCnStr);


            try
            {
                SqlCommand dbCmd = new SqlCommand("dbo.spTradeDataContractBizDateRoll", dbCn);
                dbCmd.CommandType = CommandType.StoredProcedure;
                dbCmd.CommandTimeout = int.Parse(Standard.ConfigValue("DatabaseTimeout", "300"));

                SqlParameter paramBizDatePrior = dbCmd.Parameters.Add("@BizDatePrior", SqlDbType.DateTime);
                paramBizDatePrior.Value = bizDatePrior;

                SqlParameter paramBizDate = dbCmd.Parameters.Add("@BizDate", SqlDbType.DateTime);
                paramBizDate.Value = bizDate;

                SqlParameter paramBookGroup = dbCmd.Parameters.Add("@BookGroup", SqlDbType.VarChar, 10);
                paramBookGroup.Value = bookGroup;

                SqlParameter paramRecordCount = dbCmd.Parameters.Add("@RecordCount", SqlDbType.Int);
                paramRecordCount.Direction = ParameterDirection.Output;

                dbCn.Open();
                dbCmd.ExecuteNonQuery();
                dbCn.Close();

                Log.Write("Rolled : " + long.Parse(paramRecordCount.Value.ToString()).ToString("#,##0") + " contracts; For BookGroup: " + bookGroup + ".", 1);
            }
            catch
            {
                throw;
            }
            finally
            {
                if (dbCn.State != ConnectionState.Closed)
                {
                    dbCn.Close();
                }
            }
        }

    }
}
