﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using C1.Silverlight.Data;
using C1.Silverlight.DataGrid.Ria;
using C1.Silverlight.DataGrid;
using C1.Silverlight.DataGrid.Summaries;

using C1.Silverlight;

using WorldWideClient.ServiceUserAdmin;
using WorldWideClient.ServiceBooks;

namespace WorldWideClient
{
	public partial class PositionBooksToolControl : UserControl
	{
		private string userId;
		private string bookGroup;
		private string functionPath;
		
		private UserAdminServiceClient userAdminClient;
        private BooksServiceClient booksClient;
        private DataTable dtBookGroups;


        public PositionBooksToolControl(string userId, string bookGroup, string functionPath)
		{			
			InitializeComponent();
			
			this.userId = userId;
			this.bookGroup = bookGroup;
			this.functionPath = functionPath;
			
			userAdminClient = new UserAdminServiceClient();
            userAdminClient.UserBookGroupsGetCompleted += new EventHandler<UserBookGroupsGetCompletedEventArgs>(userAdminClient_UserBookGroupsGetCompleted);

            booksClient = new BooksServiceClient();
            booksClient.BooksGetCompleted += new EventHandler<BooksGetCompletedEventArgs>(booksClient_BooksGetCompleted);
            PopulateGrid();
		}
		
		void booksClient_BooksGetCompleted(object sender, BooksGetCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                SystemEventWindow.Show(e.Error.Message);
                return;
            }

            PagedCollectionView pcv = new PagedCollectionView(Functions.ConvertToDataTable(e.Result, "Books").DefaultView);

            _dataGrid.ItemsSource = pcv;
            _dataPager.Source = pcv;            
        }

        void userAdminClient_UserBookGroupsGetCompleted(object sender, UserBookGroupsGetCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                SystemEventWindow.Show(e.Error.Message);
                return;
            }

            dtBookGroups = Functions.ConvertToDataTable(e.Result, "UserBookGroups");
            
            _dataGrid.ItemsSource = dtBookGroups.DefaultView;
        }
				
		private void PopulateGrid()
		{
			if (bookGroup.Equals(""))
			{
				DataGridTextColumn bookGroupColumn = new DataGridTextColumn();
				bookGroupColumn.Binding = new Binding("BookGroup");
				bookGroupColumn.Header = "Book Group";
				
				_dataGrid.Columns.Add(bookGroupColumn);
				
				DataGridTextColumn bookColumn = new DataGridTextColumn();
				bookColumn.Binding = new Binding("BookName");
				bookColumn.Header = "Name";
				
				_dataGrid.Columns.Add(bookColumn);             
                               
                userAdminClient.UserBookGroupsGetAsync(userId, functionPath);
			}
			else
			{
                DataGridTextColumn bookGroupColumn = new DataGridTextColumn();
                bookGroupColumn.Binding = new Binding("Book");
                bookGroupColumn.Header = "Book";

                _dataGrid.Columns.Add(bookGroupColumn);

                DataGridTextColumn bookColumn = new DataGridTextColumn();
                bookColumn.Binding = new Binding("BookName");
                bookColumn.Header = "Name";

                _dataGrid.Columns.Add(bookColumn);
      
                booksClient.BooksGetAsync(bookGroup, "", UserInformation.UserId, UserInformation.Password,functionPath);
			}


            _dataGrid.LoadedCellPresenter += new EventHandler<DataGridCellEventArgs>(_dataGrid_LoadedCellPresenter);       
		}
		
		private void mouseHelper_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
		{
			 if (bookGroup.Equals(""))
            {
                CustomEvents.UpdateUserBookGroupInformation(_dataGrid[_dataGrid.SelectedIndex, 0].Text, "");
            }
			else
			{
				CustomEvents.UpdateUserBookGroupInformation("", _dataGrid[_dataGrid.SelectedIndex, 0].Text);
			}
		}

		private void _dataGrid_LoadedCellPresenter(object sender, C1.Silverlight.DataGrid.DataGridCellEventArgs e)
		{ 
			C1MouseHelper mouseHelper = new C1MouseHelper(e.Cell.Presenter);
            mouseHelper.MouseDoubleClick += new System.Windows.Input.MouseButtonEventHandler(mouseHelper_MouseDoubleClick);
		}
	}
}