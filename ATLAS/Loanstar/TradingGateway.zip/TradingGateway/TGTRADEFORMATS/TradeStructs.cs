﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StockLoan.TGTradeFormats
{
    public struct TradeResponse
    {
        public string tradeNumber;
        public string status;
        public string statusDescription;
    }

    public class TradeStructs
    {
    }
}
