namespace CentralClient
{
  partial class AdminUsersForm
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminUsersForm));
      this.UsersGrid = new C1.Win.C1TrueDBGrid.C1TrueDBGrid();
      this.UserRoleGrid = new C1.Win.C1TrueDBGrid.C1TrueDBGrid();
      ((System.ComponentModel.ISupportInitialize)(this.UsersGrid)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.UserRoleGrid)).BeginInit();
      this.SuspendLayout();
      // 
      // UsersGrid
      // 
      this.UsersGrid.AllowAddNew = true;
      this.UsersGrid.CaptionHeight = 17;
      this.UsersGrid.ChildGrid = this.UserRoleGrid;
      this.UsersGrid.DirectionAfterEnter = C1.Win.C1TrueDBGrid.DirectionAfterEnterEnum.MoveDown;
      this.UsersGrid.Dock = System.Windows.Forms.DockStyle.Fill;
      this.UsersGrid.EmptyRows = true;
      this.UsersGrid.ExtendRightColumn = true;
      this.UsersGrid.GroupByCaption = "Drag a column header here to group by that column";
      this.UsersGrid.Images.Add(((System.Drawing.Image)(resources.GetObject("UsersGrid.Images"))));
      this.UsersGrid.Images.Add(((System.Drawing.Image)(resources.GetObject("UsersGrid.Images1"))));
      this.UsersGrid.Location = new System.Drawing.Point(0, 0);
      this.UsersGrid.Name = "UsersGrid";
      this.UsersGrid.PreviewInfo.Location = new System.Drawing.Point(0, 0);
      this.UsersGrid.PreviewInfo.Size = new System.Drawing.Size(0, 0);
      this.UsersGrid.PreviewInfo.ZoomFactor = 75;
      this.UsersGrid.PrintInfo.PageSettings = ((System.Drawing.Printing.PageSettings)(resources.GetObject("UsersGrid.PrintInfo.PageSettings")));
      this.UsersGrid.RowDivider.Color = System.Drawing.Color.DarkGray;
      this.UsersGrid.RowDivider.Style = C1.Win.C1TrueDBGrid.LineStyleEnum.None;
      this.UsersGrid.RowHeight = 15;
      this.UsersGrid.Size = new System.Drawing.Size(1519, 743);
      this.UsersGrid.TabAction = C1.Win.C1TrueDBGrid.TabActionEnum.ColumnNavigation;
      this.UsersGrid.TabIndex = 0;
      this.UsersGrid.FormatText += new C1.Win.C1TrueDBGrid.FormatTextEventHandler(this.UsersGrid_FormatText);
      this.UsersGrid.BeforeUpdate += new C1.Win.C1TrueDBGrid.CancelEventHandler(this.UsersGrid_BeforeUpdate);
      this.UsersGrid.AfterUpdate += new System.EventHandler(this.UsersGrid_AfterUpdate);
      this.UsersGrid.PropBag = resources.GetString("UsersGrid.PropBag");
      // 
      // UserRoleGrid
      // 
      this.UserRoleGrid.AllowAddNew = true;
      this.UserRoleGrid.CaptionHeight = 17;
      this.UserRoleGrid.DirectionAfterEnter = C1.Win.C1TrueDBGrid.DirectionAfterEnterEnum.MoveDown;
      this.UserRoleGrid.EmptyRows = true;
      this.UserRoleGrid.ExtendRightColumn = true;
      this.UserRoleGrid.GroupByCaption = "Drag a column header here to group by that column";
      this.UserRoleGrid.Images.Add(((System.Drawing.Image)(resources.GetObject("UserRoleGrid.Images"))));
      this.UserRoleGrid.Images.Add(((System.Drawing.Image)(resources.GetObject("UserRoleGrid.Images1"))));
      this.UserRoleGrid.Images.Add(((System.Drawing.Image)(resources.GetObject("UserRoleGrid.Images2"))));
      this.UserRoleGrid.Images.Add(((System.Drawing.Image)(resources.GetObject("UserRoleGrid.Images3"))));
      this.UserRoleGrid.Images.Add(((System.Drawing.Image)(resources.GetObject("UserRoleGrid.Images4"))));
      this.UserRoleGrid.Images.Add(((System.Drawing.Image)(resources.GetObject("UserRoleGrid.Images5"))));
      this.UserRoleGrid.Images.Add(((System.Drawing.Image)(resources.GetObject("UserRoleGrid.Images6"))));
      this.UserRoleGrid.Location = new System.Drawing.Point(54, 73);
      this.UserRoleGrid.Name = "UserRoleGrid";
      this.UserRoleGrid.PreviewInfo.Location = new System.Drawing.Point(0, 0);
      this.UserRoleGrid.PreviewInfo.Size = new System.Drawing.Size(0, 0);
      this.UserRoleGrid.PreviewInfo.ZoomFactor = 75;
      this.UserRoleGrid.PrintInfo.PageSettings = ((System.Drawing.Printing.PageSettings)(resources.GetObject("c1TrueDBGrid1.PrintInfo.PageSettings")));
      this.UserRoleGrid.RowDivider.Color = System.Drawing.Color.DarkGray;
      this.UserRoleGrid.RowDivider.Style = C1.Win.C1TrueDBGrid.LineStyleEnum.None;
      this.UserRoleGrid.RowHeight = 15;
      this.UserRoleGrid.Size = new System.Drawing.Size(863, 320);
      this.UserRoleGrid.TabAction = C1.Win.C1TrueDBGrid.TabActionEnum.ColumnNavigation;
      this.UserRoleGrid.TabIndex = 1;
      this.UserRoleGrid.TabStop = false;
      this.UserRoleGrid.PropBag = resources.GetString("UserRoleGrid.PropBag");
      // 
      // AdminUsersForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(70)))), ((int)(((byte)(70)))));
      this.ClientSize = new System.Drawing.Size(1519, 743);
      this.Controls.Add(this.UserRoleGrid);
      this.Controls.Add(this.UsersGrid);
      this.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "AdminUsersForm";
      this.Text = "Admin - Users";
      this.VisualStyleHolder = C1.Win.C1Ribbon.VisualStyle.Office2007Black;
      this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.AdminUsersForm_FormClosing);
      this.Load += new System.EventHandler(this.AdminUsersForm_Load);
      ((System.ComponentModel.ISupportInitialize)(this.UsersGrid)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.UserRoleGrid)).EndInit();
      this.ResumeLayout(false);

    }

    #endregion

    private C1.Win.C1TrueDBGrid.C1TrueDBGrid UsersGrid;
    private C1.Win.C1TrueDBGrid.C1TrueDBGrid UserRoleGrid;
  }
}