using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CentralClient
{
	/// <summary>
	/// Summary description for AdminKeyValuesForm.
	/// </summary>
	public class AdminKeyValuesForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.ListView listView1;
		private System.Windows.Forms.Button ApplyButton;
		private System.Windows.Forms.Button CancelButton;
		private C1.Win.C1TrueDBGrid.C1TrueDBGrid KeyValuesGrid;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public AdminKeyValuesForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(AdminKeyValuesForm));
			this.listView1 = new System.Windows.Forms.ListView();
			this.ApplyButton = new System.Windows.Forms.Button();
			this.CancelButton = new System.Windows.Forms.Button();
			this.KeyValuesGrid = new C1.Win.C1TrueDBGrid.C1TrueDBGrid();
			((System.ComponentModel.ISupportInitialize)(this.KeyValuesGrid)).BeginInit();
			this.SuspendLayout();
			// 
			// listView1
			// 
			this.listView1.Dock = System.Windows.Forms.DockStyle.Left;
			this.listView1.Location = new System.Drawing.Point(0, 15);
			this.listView1.Name = "listView1";
			this.listView1.Size = new System.Drawing.Size(280, 304);
			this.listView1.TabIndex = 0;
			// 
			// ApplyButton
			// 
			this.ApplyButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.ApplyButton.Location = new System.Drawing.Point(600, 324);
			this.ApplyButton.Name = "ApplyButton";
			this.ApplyButton.TabIndex = 2;
			this.ApplyButton.Text = "&Apply";
			// 
			// CancelButton
			// 
			this.CancelButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.CancelButton.Location = new System.Drawing.Point(692, 324);
			this.CancelButton.Name = "CancelButton";
			this.CancelButton.TabIndex = 3;
			this.CancelButton.Text = "Cancel";
			// 
			// KeyValuesGrid
			// 
			this.KeyValuesGrid.Dock = System.Windows.Forms.DockStyle.Fill;
			this.KeyValuesGrid.EmptyRows = true;
			this.KeyValuesGrid.ExtendRightColumn = true;
			this.KeyValuesGrid.GroupByCaption = "Drag a column header here to group by that column";
			this.KeyValuesGrid.Images.Add(((System.Drawing.Image)(resources.GetObject("resource"))));
			this.KeyValuesGrid.Location = new System.Drawing.Point(280, 15);
			this.KeyValuesGrid.Name = "KeyValuesGrid";
			this.KeyValuesGrid.PreviewInfo.Location = new System.Drawing.Point(0, 0);
			this.KeyValuesGrid.PreviewInfo.Size = new System.Drawing.Size(0, 0);
			this.KeyValuesGrid.PreviewInfo.ZoomFactor = 75;
			this.KeyValuesGrid.RecordSelectors = false;
			this.KeyValuesGrid.RowDivider.Color = System.Drawing.Color.Gainsboro;
			this.KeyValuesGrid.RowDivider.Style = C1.Win.C1TrueDBGrid.LineStyleEnum.None;
			this.KeyValuesGrid.Size = new System.Drawing.Size(492, 304);
			this.KeyValuesGrid.TabIndex = 4;
			this.KeyValuesGrid.Text = "KeyValuesGrid";
			this.KeyValuesGrid.PropBag = "<?xml version=\"1.0\"?><Blob><DataCols><C1DataColumn Caption=\"KeyId\" DataField=\"\"><" +
				"ValueItems /><GroupInfo /></C1DataColumn><C1DataColumn Caption=\"KeyValue\" DataFi" +
				"eld=\"\"><ValueItems /><GroupInfo /></C1DataColumn></DataCols><Styles type=\"C1.Win" +
				".C1TrueDBGrid.Design.ContextWrapper\"><Data>Caption{AlignHorz:Center;}Style27{}No" +
				"rmal{Font:Courier New, 8.25pt;}Style25{}Selected{ForeColor:HighlightText;BackCol" +
				"or:Highlight;}Editor{}Style18{}Style19{}Style14{}Style15{}Style16{AlignHorz:Near" +
				";}Style17{AlignHorz:Near;}Style10{AlignHorz:Near;}Style11{}OddRow{}Style13{}Styl" +
				"e12{}Footer{}HighlightRow{ForeColor:HighlightText;BackColor:Highlight;}Style26{}" +
				"RecordSelector{AlignImage:Center;}Style24{}Style23{AlignHorz:Near;}Style22{Align" +
				"Horz:Near;}Style21{}Style20{}Inactive{ForeColor:InactiveCaptionText;BackColor:In" +
				"activeCaption;}EvenRow{BackColor:Aqua;}Heading{Wrap:True;AlignVert:Center;Border" +
				":Raised,,1, 1, 1, 1;ForeColor:ControlText;BackColor:Control;}FilterBar{}Style4{}" +
				"Style9{}Style8{}Style5{}Group{BackColor:ControlDark;Border:None,,0, 0, 0, 0;Alig" +
				"nVert:Center;}Style7{}Style6{}Style1{}Style3{}Style2{}</Data></Styles><Splits><C" +
				"1.Win.C1TrueDBGrid.MergeView HBarStyle=\"None\" Name=\"\" CaptionHeight=\"17\" ColumnC" +
				"aptionHeight=\"17\" ColumnFooterHeight=\"17\" ExtendRightColumn=\"True\" MarqueeStyle=" +
				"\"DottedCellBorder\" RecordSelectorWidth=\"16\" DefRecSelWidth=\"16\" RecordSelectors=" +
				"\"False\" VerticalScrollGroup=\"1\" HorizontalScrollGroup=\"1\"><Height>300</Height><C" +
				"aptionStyle parent=\"Style2\" me=\"Style10\" /><EditorStyle parent=\"Editor\" me=\"Styl" +
				"e5\" /><EvenRowStyle parent=\"EvenRow\" me=\"Style8\" /><FilterBarStyle parent=\"Filte" +
				"rBar\" me=\"Style13\" /><FooterStyle parent=\"Footer\" me=\"Style3\" /><GroupStyle pare" +
				"nt=\"Group\" me=\"Style12\" /><HeadingStyle parent=\"Heading\" me=\"Style2\" /><HighLigh" +
				"tRowStyle parent=\"HighlightRow\" me=\"Style7\" /><InactiveStyle parent=\"Inactive\" m" +
				"e=\"Style4\" /><OddRowStyle parent=\"OddRow\" me=\"Style9\" /><RecordSelectorStyle par" +
				"ent=\"RecordSelector\" me=\"Style11\" /><SelectedStyle parent=\"Selected\" me=\"Style6\"" +
				" /><Style parent=\"Normal\" me=\"Style1\" /><internalCols><C1DisplayColumn><HeadingS" +
				"tyle parent=\"Style2\" me=\"Style16\" /><Style parent=\"Style1\" me=\"Style17\" /><Foote" +
				"rStyle parent=\"Style3\" me=\"Style18\" /><EditorStyle parent=\"Style5\" me=\"Style19\" " +
				"/><GroupHeaderStyle parent=\"Style1\" me=\"Style21\" /><GroupFooterStyle parent=\"Sty" +
				"le1\" me=\"Style20\" /><Visible>True</Visible><ColumnDivider>DarkGray,Single</Colum" +
				"nDivider><Width>242</Width><Height>15</Height><DCIdx>0</DCIdx></C1DisplayColumn>" +
				"<C1DisplayColumn><HeadingStyle parent=\"Style2\" me=\"Style22\" /><Style parent=\"Sty" +
				"le1\" me=\"Style23\" /><FooterStyle parent=\"Style3\" me=\"Style24\" /><EditorStyle par" +
				"ent=\"Style5\" me=\"Style25\" /><GroupHeaderStyle parent=\"Style1\" me=\"Style27\" /><Gr" +
				"oupFooterStyle parent=\"Style1\" me=\"Style26\" /><Visible>True</Visible><ColumnDivi" +
				"der>DarkGray,Single</ColumnDivider><Width>844</Width><Height>15</Height><DCIdx>1" +
				"</DCIdx></C1DisplayColumn></internalCols><ClientRect>0, 0, 488, 300</ClientRect>" +
				"<BorderSide>0</BorderSide><BorderStyle>Sunken</BorderStyle></C1.Win.C1TrueDBGrid" +
				".MergeView></Splits><NamedStyles><Style parent=\"\" me=\"Normal\" /><Style parent=\"N" +
				"ormal\" me=\"Heading\" /><Style parent=\"Heading\" me=\"Footer\" /><Style parent=\"Headi" +
				"ng\" me=\"Caption\" /><Style parent=\"Heading\" me=\"Inactive\" /><Style parent=\"Normal" +
				"\" me=\"Selected\" /><Style parent=\"Normal\" me=\"Editor\" /><Style parent=\"Normal\" me" +
				"=\"HighlightRow\" /><Style parent=\"Normal\" me=\"EvenRow\" /><Style parent=\"Normal\" m" +
				"e=\"OddRow\" /><Style parent=\"Heading\" me=\"RecordSelector\" /><Style parent=\"Normal" +
				"\" me=\"FilterBar\" /><Style parent=\"Caption\" me=\"Group\" /></NamedStyles><vertSplit" +
				"s>1</vertSplits><horzSplits>1</horzSplits><Layout>Modified</Layout><DefaultRecSe" +
				"lWidth>16</DefaultRecSelWidth><ClientArea>0, 0, 488, 300</ClientArea><PrintPageH" +
				"eaderStyle parent=\"\" me=\"Style14\" /><PrintPageFooterStyle parent=\"\" me=\"Style15\"" +
				" /></Blob>";
			// 
			// AdminKeyValuesForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(7, 13);
			this.ClientSize = new System.Drawing.Size(772, 349);
			this.Controls.Add(this.KeyValuesGrid);
			this.Controls.Add(this.CancelButton);
			this.Controls.Add(this.ApplyButton);
			this.Controls.Add(this.listView1);
			this.DockPadding.Bottom = 30;
			this.DockPadding.Top = 15;
			this.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "AdminKeyValuesForm";
			this.Text = "Admin - KeyValues";
			((System.ComponentModel.ISupportInitialize)(this.KeyValuesGrid)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion
	}
}
