using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CentralClient
{
	/// <summary>
	/// Summary description for AdminBooksForm.
	/// </summary>
	public class AdminBooksForm : System.Windows.Forms.Form
	{
		private C1.Win.C1TrueDBGrid.C1TrueDBGrid BooksGrid;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public AdminBooksForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(AdminBooksForm));
			this.BooksGrid = new C1.Win.C1TrueDBGrid.C1TrueDBGrid();
			((System.ComponentModel.ISupportInitialize)(this.BooksGrid)).BeginInit();
			this.SuspendLayout();
			// 
			// BooksGrid
			// 
			this.BooksGrid.Dock = System.Windows.Forms.DockStyle.Fill;
			this.BooksGrid.EmptyRows = true;
			this.BooksGrid.ExtendRightColumn = true;
			this.BooksGrid.GroupByCaption = "Drag a column header here to group by that column";
			this.BooksGrid.Images.Add(((System.Drawing.Image)(resources.GetObject("resource"))));
			this.BooksGrid.Location = new System.Drawing.Point(1, 40);
			this.BooksGrid.Name = "BooksGrid";
			this.BooksGrid.PreviewInfo.Location = new System.Drawing.Point(0, 0);
			this.BooksGrid.PreviewInfo.Size = new System.Drawing.Size(0, 0);
			this.BooksGrid.PreviewInfo.ZoomFactor = 75;
			this.BooksGrid.RowDivider.Color = System.Drawing.Color.Gainsboro;
			this.BooksGrid.RowDivider.Style = C1.Win.C1TrueDBGrid.LineStyleEnum.Single;
			this.BooksGrid.Size = new System.Drawing.Size(1206, 908);
			this.BooksGrid.TabIndex = 0;
			this.BooksGrid.PropBag = "<?xml version=\"1.0\"?><Blob><DataCols><C1DataColumn Caption=\"Book\" DataField=\"\"><V" +
				"alueItems /><GroupInfo /></C1DataColumn><C1DataColumn Caption=\"Name\" DataField=\"" +
				"\"><ValueItems /><GroupInfo /></C1DataColumn><C1DataColumn Caption=\"Phone\" DataFi" +
				"eld=\"\"><ValueItems /><GroupInfo /></C1DataColumn><C1DataColumn Caption=\"Fax\" Dat" +
				"aField=\"\"><ValueItems /><GroupInfo /></C1DataColumn></DataCols><Styles type=\"C1." +
				"Win.C1TrueDBGrid.Design.ContextWrapper\"><Data>HighlightRow{ForeColor:HighlightTe" +
				"xt;BackColor:Highlight;}Caption{AlignHorz:Center;}Normal{}Style25{}Style24{}Edit" +
				"or{}Style18{}Style19{}Style14{}Style15{}Style16{AlignHorz:Near;}Style17{AlignHor" +
				"z:Near;}Style10{AlignHorz:Near;}Style11{}OddRow{}Style13{}Style12{}Style29{Align" +
				"Horz:Near;}Style28{AlignHorz:Near;}Style27{}Style26{}RecordSelector{AlignImage:C" +
				"enter;}Footer{}Style23{AlignHorz:Near;}Style22{AlignHorz:Near;}Style21{}Style20{" +
				"}Group{BackColor:ControlDark;Border:None,,0, 0, 0, 0;AlignVert:Center;}Inactive{" +
				"ForeColor:InactiveCaptionText;BackColor:InactiveCaption;}EvenRow{BackColor:Aqua;" +
				"}Heading{Wrap:True;AlignVert:Center;Border:Raised,,1, 1, 1, 1;ForeColor:ControlT" +
				"ext;BackColor:Control;}Style3{}Style6{}Style1{}Style5{}Style7{}Style8{}FilterBar" +
				"{}Selected{ForeColor:HighlightText;BackColor:Highlight;}Style4{}Style9{}Style38{" +
				"}Style39{}Style36{}Style37{}Style34{AlignHorz:Near;}Style35{AlignHorz:Near;}Styl" +
				"e32{}Style33{}Style30{}Style31{}Style2{}</Data></Styles><Splits><C1.Win.C1TrueDB" +
				"Grid.MergeView Name=\"\" CaptionHeight=\"17\" ColumnCaptionHeight=\"17\" ColumnFooterH" +
				"eight=\"17\" ExtendRightColumn=\"True\" MarqueeStyle=\"DottedCellBorder\" RecordSelect" +
				"orWidth=\"16\" DefRecSelWidth=\"16\" VerticalScrollGroup=\"1\" HorizontalScrollGroup=\"" +
				"1\"><Height>904</Height><CaptionStyle parent=\"Style2\" me=\"Style10\" /><EditorStyle" +
				" parent=\"Editor\" me=\"Style5\" /><EvenRowStyle parent=\"EvenRow\" me=\"Style8\" /><Fil" +
				"terBarStyle parent=\"FilterBar\" me=\"Style13\" /><FooterStyle parent=\"Footer\" me=\"S" +
				"tyle3\" /><GroupStyle parent=\"Group\" me=\"Style12\" /><HeadingStyle parent=\"Heading" +
				"\" me=\"Style2\" /><HighLightRowStyle parent=\"HighlightRow\" me=\"Style7\" /><Inactive" +
				"Style parent=\"Inactive\" me=\"Style4\" /><OddRowStyle parent=\"OddRow\" me=\"Style9\" /" +
				"><RecordSelectorStyle parent=\"RecordSelector\" me=\"Style11\" /><SelectedStyle pare" +
				"nt=\"Selected\" me=\"Style6\" /><Style parent=\"Normal\" me=\"Style1\" /><internalCols><" +
				"C1DisplayColumn><HeadingStyle parent=\"Style2\" me=\"Style16\" /><Style parent=\"Styl" +
				"e1\" me=\"Style17\" /><FooterStyle parent=\"Style3\" me=\"Style18\" /><EditorStyle pare" +
				"nt=\"Style5\" me=\"Style19\" /><GroupHeaderStyle parent=\"Style1\" me=\"Style21\" /><Gro" +
				"upFooterStyle parent=\"Style1\" me=\"Style20\" /><Visible>True</Visible><ColumnDivid" +
				"er>DarkGray,Single</ColumnDivider><Width>132</Width><Height>15</Height><DCIdx>0<" +
				"/DCIdx></C1DisplayColumn><C1DisplayColumn><HeadingStyle parent=\"Style2\" me=\"Styl" +
				"e22\" /><Style parent=\"Style1\" me=\"Style23\" /><FooterStyle parent=\"Style3\" me=\"St" +
				"yle24\" /><EditorStyle parent=\"Style5\" me=\"Style25\" /><GroupHeaderStyle parent=\"S" +
				"tyle1\" me=\"Style27\" /><GroupFooterStyle parent=\"Style1\" me=\"Style26\" /><Visible>" +
				"True</Visible><ColumnDivider>DarkGray,Single</ColumnDivider><Width>210</Width><H" +
				"eight>15</Height><DCIdx>1</DCIdx></C1DisplayColumn><C1DisplayColumn><HeadingStyl" +
				"e parent=\"Style2\" me=\"Style28\" /><Style parent=\"Style1\" me=\"Style29\" /><FooterSt" +
				"yle parent=\"Style3\" me=\"Style30\" /><EditorStyle parent=\"Style5\" me=\"Style31\" /><" +
				"GroupHeaderStyle parent=\"Style1\" me=\"Style33\" /><GroupFooterStyle parent=\"Style1" +
				"\" me=\"Style32\" /><Visible>True</Visible><ColumnDivider>Gainsboro,Single</ColumnD" +
				"ivider><Width>234</Width><Height>15</Height><DCIdx>2</DCIdx></C1DisplayColumn><C" +
				"1DisplayColumn><HeadingStyle parent=\"Style2\" me=\"Style34\" /><Style parent=\"Style" +
				"1\" me=\"Style35\" /><FooterStyle parent=\"Style3\" me=\"Style36\" /><EditorStyle paren" +
				"t=\"Style5\" me=\"Style37\" /><GroupHeaderStyle parent=\"Style1\" me=\"Style39\" /><Grou" +
				"pFooterStyle parent=\"Style1\" me=\"Style38\" /><Visible>True</Visible><ColumnDivide" +
				"r>DarkGray,Single</ColumnDivider><Height>15</Height><DCIdx>3</DCIdx></C1DisplayC" +
				"olumn></internalCols><ClientRect>0, 0, 1202, 904</ClientRect><BorderSide>0</Bord" +
				"erSide><BorderStyle>Bump</BorderStyle></C1.Win.C1TrueDBGrid.MergeView></Splits><" +
				"NamedStyles><Style parent=\"\" me=\"Normal\" /><Style parent=\"Normal\" me=\"Heading\" /" +
				"><Style parent=\"Heading\" me=\"Footer\" /><Style parent=\"Heading\" me=\"Caption\" /><S" +
				"tyle parent=\"Heading\" me=\"Inactive\" /><Style parent=\"Normal\" me=\"Selected\" /><St" +
				"yle parent=\"Normal\" me=\"Editor\" /><Style parent=\"Normal\" me=\"HighlightRow\" /><St" +
				"yle parent=\"Normal\" me=\"EvenRow\" /><Style parent=\"Normal\" me=\"OddRow\" /><Style p" +
				"arent=\"Heading\" me=\"RecordSelector\" /><Style parent=\"Normal\" me=\"FilterBar\" /><S" +
				"tyle parent=\"Caption\" me=\"Group\" /></NamedStyles><vertSplits>1</vertSplits><horz" +
				"Splits>1</horzSplits><Layout>Modified</Layout><DefaultRecSelWidth>16</DefaultRec" +
				"SelWidth><ClientArea>0, 0, 1202, 904</ClientArea><PrintPageHeaderStyle parent=\"\"" +
				" me=\"Style14\" /><PrintPageFooterStyle parent=\"\" me=\"Style15\" /></Blob>";
			// 
			// AdminBooksForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(1208, 949);
			this.Controls.Add(this.BooksGrid);
			this.DockPadding.Bottom = 1;
			this.DockPadding.Left = 1;
			this.DockPadding.Right = 1;
			this.DockPadding.Top = 40;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "AdminBooksForm";
			this.Text = "Admin - Books";
			((System.ComponentModel.ISupportInitialize)(this.BooksGrid)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion
	}
}
