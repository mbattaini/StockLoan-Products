using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CentralClient
{
	/// <summary>
	/// Summary description for AdminHolidaysForm.
	/// </summary>
	public class AdminHolidaysForm : System.Windows.Forms.Form
	{
		private C1.Win.C1TrueDBGrid.C1TrueDBGrid c1TrueDBGrid1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public AdminHolidaysForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(AdminHolidaysForm));
			this.c1TrueDBGrid1 = new C1.Win.C1TrueDBGrid.C1TrueDBGrid();
			((System.ComponentModel.ISupportInitialize)(this.c1TrueDBGrid1)).BeginInit();
			this.SuspendLayout();
			// 
			// c1TrueDBGrid1
			// 
			this.c1TrueDBGrid1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.c1TrueDBGrid1.EmptyRows = true;
			this.c1TrueDBGrid1.ExtendRightColumn = true;
			this.c1TrueDBGrid1.GroupByCaption = "Drag a column header here to group by that column";
			this.c1TrueDBGrid1.Images.Add(((System.Drawing.Image)(resources.GetObject("resource"))));
			this.c1TrueDBGrid1.Location = new System.Drawing.Point(1, 1);
			this.c1TrueDBGrid1.Name = "c1TrueDBGrid1";
			this.c1TrueDBGrid1.PreviewInfo.Location = new System.Drawing.Point(0, 0);
			this.c1TrueDBGrid1.PreviewInfo.Size = new System.Drawing.Size(0, 0);
			this.c1TrueDBGrid1.PreviewInfo.ZoomFactor = 75;
			this.c1TrueDBGrid1.RowDivider.Color = System.Drawing.Color.Gainsboro;
			this.c1TrueDBGrid1.RowDivider.Style = C1.Win.C1TrueDBGrid.LineStyleEnum.Single;
			this.c1TrueDBGrid1.Size = new System.Drawing.Size(702, 547);
			this.c1TrueDBGrid1.TabIndex = 0;
			this.c1TrueDBGrid1.Text = "c1TrueDBGrid1";
			this.c1TrueDBGrid1.PropBag = "<?xml version=\"1.0\"?><Blob><DataCols><C1DataColumn Caption=\"Date\" DataField=\"\"><V" +
				"alueItems /><GroupInfo /></C1DataColumn><C1DataColumn Caption=\"Country Code\" Dat" +
				"aField=\"\"><ValueItems /><GroupInfo /></C1DataColumn><C1DataColumn Caption=\"Bank " +
				"Holiday\" DataField=\"\"><ValueItems /><GroupInfo /></C1DataColumn><C1DataColumn Ca" +
				"ption=\"Exchange Holiday\" DataField=\"\"><ValueItems /><GroupInfo /></C1DataColumn>" +
				"<C1DataColumn Caption=\"ActUserId\" DataField=\"ActUserId\"><ValueItems /><GroupInfo" +
				" /></C1DataColumn></DataCols><Styles type=\"C1.Win.C1TrueDBGrid.Design.ContextWra" +
				"pper\"><Data>HighlightRow{ForeColor:HighlightText;BackColor:Highlight;}Caption{Al" +
				"ignHorz:Center;}Normal{}Style25{}Selected{ForeColor:HighlightText;BackColor:High" +
				"light;}Editor{}Style18{}Style19{}Style14{}Style15{}Style16{AlignHorz:Near;}Style" +
				"17{AlignHorz:Near;}Style10{AlignHorz:Near;}Style11{}OddRow{}Style13{}FilterBar{}" +
				"Style12{}Style29{AlignHorz:Center;}Style28{AlignHorz:Near;}Style27{}Style26{}Rec" +
				"ordSelector{AlignImage:Center;}Footer{}Style23{AlignHorz:Near;}Style22{AlignHorz" +
				":Near;}Style21{}Style20{}Group{BackColor:ControlDark;Border:None,,0, 0, 0, 0;Ali" +
				"gnVert:Center;}Inactive{ForeColor:InactiveCaptionText;BackColor:InactiveCaption;" +
				"}EvenRow{BackColor:Aqua;}Style6{}Heading{Wrap:True;AlignVert:Center;Border:Raise" +
				"d,,1, 1, 1, 1;ForeColor:ControlText;BackColor:Control;}Style3{}Style24{}Style7{}" +
				"Style8{}Style1{}Style5{}Style41{AlignHorz:Near;}Style40{AlignHorz:Near;}Style43{" +
				"}Style42{}Style45{}Style44{}Style4{}Style9{}Style38{}Style39{}Style36{}Style37{}" +
				"Style34{AlignHorz:Near;}Style35{AlignHorz:Center;}Style32{}Style33{}Style30{}Sty" +
				"le31{}Style2{}</Data></Styles><Splits><C1.Win.C1TrueDBGrid.MergeView Name=\"\" Cap" +
				"tionHeight=\"17\" ColumnCaptionHeight=\"17\" ColumnFooterHeight=\"17\" ExtendRightColu" +
				"mn=\"True\" MarqueeStyle=\"DottedCellBorder\" RecordSelectorWidth=\"16\" DefRecSelWidt" +
				"h=\"16\" VerticalScrollGroup=\"1\" HorizontalScrollGroup=\"1\"><Height>543</Height><Ca" +
				"ptionStyle parent=\"Style2\" me=\"Style10\" /><EditorStyle parent=\"Editor\" me=\"Style" +
				"5\" /><EvenRowStyle parent=\"EvenRow\" me=\"Style8\" /><FilterBarStyle parent=\"Filter" +
				"Bar\" me=\"Style13\" /><FooterStyle parent=\"Footer\" me=\"Style3\" /><GroupStyle paren" +
				"t=\"Group\" me=\"Style12\" /><HeadingStyle parent=\"Heading\" me=\"Style2\" /><HighLight" +
				"RowStyle parent=\"HighlightRow\" me=\"Style7\" /><InactiveStyle parent=\"Inactive\" me" +
				"=\"Style4\" /><OddRowStyle parent=\"OddRow\" me=\"Style9\" /><RecordSelectorStyle pare" +
				"nt=\"RecordSelector\" me=\"Style11\" /><SelectedStyle parent=\"Selected\" me=\"Style6\" " +
				"/><Style parent=\"Normal\" me=\"Style1\" /><internalCols><C1DisplayColumn><HeadingSt" +
				"yle parent=\"Style2\" me=\"Style16\" /><Style parent=\"Style1\" me=\"Style17\" /><Footer" +
				"Style parent=\"Style3\" me=\"Style18\" /><EditorStyle parent=\"Style5\" me=\"Style19\" /" +
				"><GroupHeaderStyle parent=\"Style1\" me=\"Style21\" /><GroupFooterStyle parent=\"Styl" +
				"e1\" me=\"Style20\" /><Visible>True</Visible><ColumnDivider>DarkGray,Single</Column" +
				"Divider><Height>15</Height><DCIdx>0</DCIdx></C1DisplayColumn><C1DisplayColumn><H" +
				"eadingStyle parent=\"Style2\" me=\"Style22\" /><Style parent=\"Style1\" me=\"Style23\" /" +
				"><FooterStyle parent=\"Style3\" me=\"Style24\" /><EditorStyle parent=\"Style5\" me=\"St" +
				"yle25\" /><GroupHeaderStyle parent=\"Style1\" me=\"Style27\" /><GroupFooterStyle pare" +
				"nt=\"Style1\" me=\"Style26\" /><Visible>True</Visible><ColumnDivider>DarkGray,Single" +
				"</ColumnDivider><Height>15</Height><DCIdx>1</DCIdx></C1DisplayColumn><C1DisplayC" +
				"olumn><HeadingStyle parent=\"Style2\" me=\"Style28\" /><Style parent=\"Style1\" me=\"St" +
				"yle29\" /><FooterStyle parent=\"Style3\" me=\"Style30\" /><EditorStyle parent=\"Style5" +
				"\" me=\"Style31\" /><GroupHeaderStyle parent=\"Style1\" me=\"Style33\" /><GroupFooterSt" +
				"yle parent=\"Style1\" me=\"Style32\" /><Visible>True</Visible><ColumnDivider>DarkGra" +
				"y,Single</ColumnDivider><Height>15</Height><DCIdx>2</DCIdx></C1DisplayColumn><C1" +
				"DisplayColumn><HeadingStyle parent=\"Style2\" me=\"Style34\" /><Style parent=\"Style1" +
				"\" me=\"Style35\" /><FooterStyle parent=\"Style3\" me=\"Style36\" /><EditorStyle parent" +
				"=\"Style5\" me=\"Style37\" /><GroupHeaderStyle parent=\"Style1\" me=\"Style39\" /><Group" +
				"FooterStyle parent=\"Style1\" me=\"Style38\" /><Visible>True</Visible><ColumnDivider" +
				">Gainsboro,Single</ColumnDivider><Height>15</Height><DCIdx>3</DCIdx></C1DisplayC" +
				"olumn><C1DisplayColumn><HeadingStyle parent=\"Style2\" me=\"Style40\" /><Style paren" +
				"t=\"Style1\" me=\"Style41\" /><FooterStyle parent=\"Style3\" me=\"Style42\" /><EditorSty" +
				"le parent=\"Style5\" me=\"Style43\" /><GroupHeaderStyle parent=\"Style1\" me=\"Style45\"" +
				" /><GroupFooterStyle parent=\"Style1\" me=\"Style44\" /><Visible>True</Visible><Colu" +
				"mnDivider>Gainsboro,Single</ColumnDivider><Height>15</Height><DCIdx>4</DCIdx></C" +
				"1DisplayColumn></internalCols><ClientRect>0, 0, 698, 543</ClientRect><BorderSide" +
				">0</BorderSide><BorderStyle>Sunken</BorderStyle></C1.Win.C1TrueDBGrid.MergeView>" +
				"</Splits><NamedStyles><Style parent=\"\" me=\"Normal\" /><Style parent=\"Normal\" me=\"" +
				"Heading\" /><Style parent=\"Heading\" me=\"Footer\" /><Style parent=\"Heading\" me=\"Cap" +
				"tion\" /><Style parent=\"Heading\" me=\"Inactive\" /><Style parent=\"Normal\" me=\"Selec" +
				"ted\" /><Style parent=\"Normal\" me=\"Editor\" /><Style parent=\"Normal\" me=\"Highlight" +
				"Row\" /><Style parent=\"Normal\" me=\"EvenRow\" /><Style parent=\"Normal\" me=\"OddRow\" " +
				"/><Style parent=\"Heading\" me=\"RecordSelector\" /><Style parent=\"Normal\" me=\"Filte" +
				"rBar\" /><Style parent=\"Caption\" me=\"Group\" /></NamedStyles><vertSplits>1</vertSp" +
				"lits><horzSplits>1</horzSplits><Layout>Modified</Layout><DefaultRecSelWidth>16</" +
				"DefaultRecSelWidth><ClientArea>0, 0, 698, 543</ClientArea><PrintPageHeaderStyle " +
				"parent=\"\" me=\"Style14\" /><PrintPageFooterStyle parent=\"\" me=\"Style15\" /></Blob>";
			// 
			// AdminHolidaysForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(704, 549);
			this.Controls.Add(this.c1TrueDBGrid1);
			this.DockPadding.All = 1;
			this.Name = "AdminHolidaysForm";
			this.Text = "AdminHolidaysForm";
			((System.ComponentModel.ISupportInitialize)(this.c1TrueDBGrid1)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion
	}
}
