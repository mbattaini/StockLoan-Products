using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using StockLoan.Common;

namespace CentralClient
{
  public partial class AdminUsersForm : C1.Win.C1Ribbon.C1RibbonForm
  {

    private MainForm mainForm = null;
    private DataSet ds = null;

    public AdminUsersForm(MainForm mainForm)
    {
      InitializeComponent();

      this.mainForm = mainForm;
    }

    private void AdminUsersForm_Load(object sender, EventArgs e)
    {
      try
      {
        this.Top = int.Parse(RegistryValue.Read(this.Name, "Top", "25"));
        this.Left = int.Parse(RegistryValue.Read(this.Name, "Left", "25"));
        this.Height = int.Parse(RegistryValue.Read(this.Name, "Height", this.Height.ToString()));
        this.Width = int.Parse(RegistryValue.Read(this.Name, "Width", this.Width.ToString()));

        ds = mainForm.AdminAgent.UserRolesGet(mainForm.UtcOffset);

        UsersGrid.SetDataBinding(ds, "Users", true);
      }
      catch (Exception error)
      {
        mainForm.Alert(this.Name, error.Message);
      }
    }

    private void UsersGrid_AfterUpdate(object sender, EventArgs e)
    {
      try
      {
        mainForm.AdminAgent.UserSet(
          UsersGrid.Columns["UserId"].Text,
          UsersGrid.Columns["ShortName"].Text,
          UsersGrid.Columns["Password"].Text,
          UsersGrid.Columns["Email"].Text,
          UsersGrid.Columns["Group"].Text,
          UsersGrid.Columns["Comment"].Text,
          "ADMIN",
         true);

        UsersGrid.Columns["Actor"].Text = "ADMIN";
        UsersGrid.Columns["ActTime"].Value = DateTime.Now.ToString();
      }
      catch (Exception error)
      {
        mainForm.Alert(this.Name, error.Message);
      }
    }

    private void AdminUsersForm_FormClosing(object sender, FormClosingEventArgs e)
    {
      if (this.WindowState.Equals(FormWindowState.Normal) && this.Dock.Equals(DockStyle.None))
      {
        RegistryValue.Write(this.Name, "Top", this.Top.ToString());
        RegistryValue.Write(this.Name, "Left", this.Left.ToString());
        RegistryValue.Write(this.Name, "Height", this.Height.ToString());
        RegistryValue.Write(this.Name, "Width", this.Width.ToString());
      }
      
      mainForm.adminUsersForm = null;
    }



    private void UsersGrid_BeforeUpdate(object sender, C1.Win.C1TrueDBGrid.CancelEventArgs e)
    {

    }

    private void UsersGrid_FormatText(object sender, C1.Win.C1TrueDBGrid.FormatTextEventArgs e)
    {
      switch (UsersGrid.Columns[e.ColIndex].DataField)
      {
        case "ActTime":
          try
          {
            e.Value = DateTime.Parse(e.Value.ToString()).ToString(Standard.DateTimeShortFormat);
          }
          catch { }
          break;

        case "LastAccess":
          try
          {
            e.Value = DateTime.Parse(e.Value.ToString()).ToString(Standard.DateTimeShortFormat);
          }
          catch { }
          break;

        case "UsageCount":
          try
          {
            e.Value = long.Parse(e.Value.ToString()).ToString("#,##0");
          }
          catch { }
          break;

        default:
          break;
      }
    }
  }
}