namespace CentralClient
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
          this.components = new System.ComponentModel.Container();
          System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
          this.MainCommandHolder = new C1.Win.C1Command.C1CommandHolder();
          this.MainContextMenu = new C1.Win.C1Command.C1ContextMenu();
          this.c1CommandLink1 = new C1.Win.C1Command.C1CommandLink();
          this.DockLeftCommand = new C1.Win.C1Command.C1Command();
          this.c1CommandControl1 = new C1.Win.C1Command.C1CommandControl();
          this.AvailabilityCommand = new C1.Win.C1Command.C1Command();
          this.c1NavBarHorizontalRule1 = new C1.Win.C1Command.C1NavBarHorizontalRule();
          this.c1CommandLink2 = new C1.Win.C1Command.C1CommandLink();
          this.MainRibbon = new C1.Win.C1Ribbon.C1Ribbon();
          this.RibbonMainMenu = new C1.Win.C1Ribbon.RibbonApplicationMenu();
          this.ribbonConfigToolBar1 = new C1.Win.C1Ribbon.RibbonConfigToolBar();
          this.ribbonQat1 = new C1.Win.C1Ribbon.RibbonQat();
          this.AdminRibbon = new C1.Win.C1Ribbon.RibbonTab();
          this.AdminSystemSettingsGroup = new C1.Win.C1Ribbon.RibbonGroup();
          this.AdminHolidayButton = new C1.Win.C1Ribbon.RibbonButton();
          this.AdminKeyValuesButton = new C1.Win.C1Ribbon.RibbonButton();
          this.AdminUserSettingsGroup = new C1.Win.C1Ribbon.RibbonGroup();
          this.AdminFontButton = new C1.Win.C1Ribbon.RibbonButton();
          this.AdminRolesButton = new C1.Win.C1Ribbon.RibbonButton();
          this.AdminUsersButton = new C1.Win.C1Ribbon.RibbonButton();
          this.AdminClientSettingsGroup = new C1.Win.C1Ribbon.RibbonGroup();
          this.AdminBookButton = new C1.Win.C1Ribbon.RibbonButton();
          this.AdminSlaContractsButton = new C1.Win.C1Ribbon.RibbonButton();
          this.AdminGroupCodeParameterButton = new C1.Win.C1Ribbon.RibbonButton();
          this.ribbonGroup1 = new C1.Win.C1Ribbon.RibbonGroup();
          this.AdminSecMasterButton = new C1.Win.C1Ribbon.RibbonButton();
          this.InventoryRibbon = new C1.Win.C1Ribbon.RibbonTab();
          this.InventorySubscriberGroup = new C1.Win.C1Ribbon.RibbonGroup();
          this.InventorySubscriptionsButton = new C1.Win.C1Ribbon.RibbonButton();
          this.InventoryUploadButton = new C1.Win.C1Ribbon.RibbonButton();
          this.InventoryPublisherGroup = new C1.Win.C1Ribbon.RibbonGroup();
          this.InventoryPublicationsButton = new C1.Win.C1Ribbon.RibbonButton();
          this.InventoryDownloadButton = new C1.Win.C1Ribbon.RibbonButton();
          this.InventoryManagementGroup = new C1.Win.C1Ribbon.RibbonGroup();
          this.InventoryCentralButton = new C1.Win.C1Ribbon.RibbonButton();
          this.InventorySettingsButton = new C1.Win.C1Ribbon.RibbonButton();
          this.TradingRibbon = new C1.Win.C1Ribbon.RibbonTab();
          this.TradingBorrowsLoansGroup = new C1.Win.C1Ribbon.RibbonGroup();
          this.TradingDeskInputButton = new C1.Win.C1Ribbon.RibbonButton();
          this.TradingContractBlotterButton = new C1.Win.C1Ribbon.RibbonButton();
          this.ribbonButton4 = new C1.Win.C1Ribbon.RibbonButton();
          this.TradingAdvancedBorrowsButton = new C1.Win.C1Ribbon.RibbonButton();
          this.TradingSummaryGroup = new C1.Win.C1Ribbon.RibbonGroup();
          this.TradingBoxSummaryButton = new C1.Win.C1Ribbon.RibbonButton();
          this.TradingContractSummaryButton = new C1.Win.C1Ribbon.RibbonButton();
          this.TradingManagementGroup = new C1.Win.C1Ribbon.RibbonGroup();
          this.ribbonButton2 = new C1.Win.C1Ribbon.RibbonButton();
          this.ribbonButton3 = new C1.Win.C1Ribbon.RibbonButton();
          this.TradingSettlementActivityButton = new C1.Win.C1Ribbon.RibbonButton();
          this.TradingToolbarsGroup = new C1.Win.C1Ribbon.RibbonGroup();
          this.TradingToolBarAvailabilityForm = new C1.Win.C1Ribbon.RibbonButton();
          this.ribbonButton1 = new C1.Win.C1Ribbon.RibbonButton();
          this.AnalysisRibbon = new C1.Win.C1Ribbon.RibbonTab();
          this.ribbonGroup3 = new C1.Win.C1Ribbon.RibbonGroup();
          this.ExitButton = new C1.Win.C1Input.C1Button();
          this.ShellAppBar = new LogicNP.ShellObjects.ShellAppBar(this.components);
          this.ErrorMessageButton = new C1.Win.C1Input.C1Button();
          this.CountLabel = new C1.Win.C1Input.C1Label();
          this.CountTextBox = new C1.Win.C1Input.C1TextBox();
          this.MainFontDialog = new System.Windows.Forms.FontDialog();
          ((System.ComponentModel.ISupportInitialize)(this.MainCommandHolder)).BeginInit();
          ((System.ComponentModel.ISupportInitialize)(this.MainRibbon)).BeginInit();
          ((System.ComponentModel.ISupportInitialize)(this.ShellAppBar)).BeginInit();
          ((System.ComponentModel.ISupportInitialize)(this.CountLabel)).BeginInit();
          ((System.ComponentModel.ISupportInitialize)(this.CountTextBox)).BeginInit();
          this.SuspendLayout();
          // 
          // MainCommandHolder
          // 
          this.MainCommandHolder.Commands.Add(this.MainContextMenu);
          this.MainCommandHolder.Commands.Add(this.DockLeftCommand);
          this.MainCommandHolder.Commands.Add(this.c1CommandControl1);
          this.MainCommandHolder.Commands.Add(this.AvailabilityCommand);
          this.MainCommandHolder.Owner = this;
          this.MainCommandHolder.VisualStyle = C1.Win.C1Command.VisualStyle.Office2007Black;
          // 
          // MainContextMenu
          // 
          this.MainContextMenu.CommandLinks.AddRange(new C1.Win.C1Command.C1CommandLink[] {
            this.c1CommandLink1});
          this.MainContextMenu.Name = "MainContextMenu";
          this.MainContextMenu.VisualStyle = C1.Win.C1Command.VisualStyle.Office2007Black;
          this.MainContextMenu.VisualStyleBase = C1.Win.C1Command.VisualStyle.Office2007Black;
          // 
          // c1CommandLink1
          // 
          this.c1CommandLink1.Command = this.DockLeftCommand;
          this.c1CommandLink1.Text = "Dock Left";
          // 
          // DockLeftCommand
          // 
          this.DockLeftCommand.Name = "DockLeftCommand";
          this.DockLeftCommand.Text = "Dock Left";
          // 
          // c1CommandControl1
          // 
          this.c1CommandControl1.Name = "c1CommandControl1";
          // 
          // AvailabilityCommand
          // 
          this.AvailabilityCommand.Icon = ((System.Drawing.Icon)(resources.GetObject("AvailabilityCommand.Icon")));
          this.AvailabilityCommand.Name = "AvailabilityCommand";
          this.AvailabilityCommand.Text = "Availability";
          // 
          // c1NavBarHorizontalRule1
          // 
          this.c1NavBarHorizontalRule1.Dock = System.Windows.Forms.DockStyle.Top;
          this.c1NavBarHorizontalRule1.Location = new System.Drawing.Point(0, 0);
          this.c1NavBarHorizontalRule1.Name = "c1NavBarHorizontalRule1";
          this.c1NavBarHorizontalRule1.Size = new System.Drawing.Size(0, 2);
          // 
          // MainRibbon
          // 
          this.MainRibbon.ApplicationMenuHolder = this.RibbonMainMenu;
          this.MainRibbon.ConfigToolBarHolder = this.ribbonConfigToolBar1;
          this.MainRibbon.MinimumHeight = 125;
          this.MainRibbon.Name = "MainRibbon";
          this.MainRibbon.QatHolder = this.ribbonQat1;
          this.MainRibbon.Tabs.Add(this.AdminRibbon);
          this.MainRibbon.Tabs.Add(this.InventoryRibbon);
          this.MainRibbon.Tabs.Add(this.TradingRibbon);
          this.MainRibbon.Tabs.Add(this.AnalysisRibbon);
          this.MainRibbon.VisualStyle = C1.Win.C1Ribbon.VisualStyle.Office2007Black;
          // 
          // RibbonMainMenu
          // 
          this.RibbonMainMenu.DropDownWidth = 0;
          this.RibbonMainMenu.ID = "RibbonMainMenu";
          this.RibbonMainMenu.LargeImage = ((System.Drawing.Image)(resources.GetObject("RibbonMainMenu.LargeImage")));
          this.RibbonMainMenu.SmallImage = ((System.Drawing.Image)(resources.GetObject("RibbonMainMenu.SmallImage")));
          // 
          // ribbonConfigToolBar1
          // 
          this.ribbonConfigToolBar1.Enabled = false;
          this.ribbonConfigToolBar1.ID = "ribbonConfigToolBar1";
          this.ribbonConfigToolBar1.Visible = false;
          // 
          // ribbonQat1
          // 
          this.ribbonQat1.ID = "ribbonQat1";
          // 
          // AdminRibbon
          // 
          this.AdminRibbon.Groups.Add(this.AdminSystemSettingsGroup);
          this.AdminRibbon.Groups.Add(this.AdminUserSettingsGroup);
          this.AdminRibbon.Groups.Add(this.AdminClientSettingsGroup);
          this.AdminRibbon.Groups.Add(this.ribbonGroup1);
          this.AdminRibbon.ID = "AdminRibbon";
          this.AdminRibbon.Text = "Administration";
          // 
          // AdminSystemSettingsGroup
          // 
          this.AdminSystemSettingsGroup.ID = "AdminSystemSettingsGroup";
          this.AdminSystemSettingsGroup.Items.Add(this.AdminHolidayButton);
          this.AdminSystemSettingsGroup.Items.Add(this.AdminKeyValuesButton);
          this.AdminSystemSettingsGroup.Text = "System Settings";
          // 
          // AdminHolidayButton
          // 
          this.AdminHolidayButton.ID = "AdminHolidayButton";
          this.AdminHolidayButton.SmallImage = ((System.Drawing.Image)(resources.GetObject("AdminHolidayButton.SmallImage")));
          this.AdminHolidayButton.Text = "Holidays";
          this.AdminHolidayButton.Click += new System.EventHandler(this.AdminHolidayButton_Click);
          // 
          // AdminKeyValuesButton
          // 
          this.AdminKeyValuesButton.ID = "AdminKeyValuesButton";
          this.AdminKeyValuesButton.SmallImage = ((System.Drawing.Image)(resources.GetObject("AdminKeyValuesButton.SmallImage")));
          this.AdminKeyValuesButton.Text = "Key Values";
          this.AdminKeyValuesButton.Click += new System.EventHandler(this.AdminKeyValuesButton_Click);
          // 
          // AdminUserSettingsGroup
          // 
          this.AdminUserSettingsGroup.ID = "AdminUserSettingsGroup";
          this.AdminUserSettingsGroup.Items.Add(this.AdminFontButton);
          this.AdminUserSettingsGroup.Items.Add(this.AdminRolesButton);
          this.AdminUserSettingsGroup.Items.Add(this.AdminUsersButton);
          this.AdminUserSettingsGroup.Text = "User Settings";
          // 
          // AdminFontButton
          // 
          this.AdminFontButton.ID = "AdminFontButton";
          this.AdminFontButton.SmallImage = ((System.Drawing.Image)(resources.GetObject("AdminFontButton.SmallImage")));
          this.AdminFontButton.Text = "Fonts";
          this.AdminFontButton.Click += new System.EventHandler(this.AdminFontButton_Click);
          // 
          // AdminRolesButton
          // 
          this.AdminRolesButton.Enabled = false;
          this.AdminRolesButton.ID = "AdminRolesButton";
          this.AdminRolesButton.LargeImage = ((System.Drawing.Image)(resources.GetObject("AdminRolesButton.LargeImage")));
          this.AdminRolesButton.SmallImage = ((System.Drawing.Image)(resources.GetObject("AdminRolesButton.SmallImage")));
          this.AdminRolesButton.Text = "Roles";
          // 
          // AdminUsersButton
          // 
          this.AdminUsersButton.ID = "AdminUsersButton";
          this.AdminUsersButton.SmallImage = ((System.Drawing.Image)(resources.GetObject("AdminUsersButton.SmallImage")));
          this.AdminUsersButton.Text = "Users";
          this.AdminUsersButton.Click += new System.EventHandler(this.AdminUsersButton_Click);
          // 
          // AdminClientSettingsGroup
          // 
          this.AdminClientSettingsGroup.ID = "AdminClientSettingsGroup";
          this.AdminClientSettingsGroup.Items.Add(this.AdminBookButton);
          this.AdminClientSettingsGroup.Items.Add(this.AdminSlaContractsButton);
          this.AdminClientSettingsGroup.Items.Add(this.AdminGroupCodeParameterButton);
          this.AdminClientSettingsGroup.Text = "Client Settings";
          // 
          // AdminBookButton
          // 
          this.AdminBookButton.ID = "AdminBookButton";
          this.AdminBookButton.SmallImage = ((System.Drawing.Image)(resources.GetObject("AdminBookButton.SmallImage")));
          this.AdminBookButton.Text = "Book Information";
          this.AdminBookButton.Click += new System.EventHandler(this.AdminCounterPartyButton_Click);
          // 
          // AdminSlaContractsButton
          // 
          this.AdminSlaContractsButton.Enabled = false;
          this.AdminSlaContractsButton.ID = "AdminSlaContractsButton";
          this.AdminSlaContractsButton.SmallImage = ((System.Drawing.Image)(resources.GetObject("AdminSlaContractsButton.SmallImage")));
          this.AdminSlaContractsButton.Text = "SLA Contracts";
          // 
          // AdminGroupCodeParameterButton
          // 
          this.AdminGroupCodeParameterButton.Enabled = false;
          this.AdminGroupCodeParameterButton.ID = "AdminGroupCodeParameterButton";
          this.AdminGroupCodeParameterButton.SmallImage = ((System.Drawing.Image)(resources.GetObject("AdminGroupCodeParameterButton.SmallImage")));
          this.AdminGroupCodeParameterButton.Text = "GroupCode Params";
          // 
          // ribbonGroup1
          // 
          this.ribbonGroup1.ID = "ribbonGroup1";
          this.ribbonGroup1.Items.Add(this.AdminSecMasterButton);
          this.ribbonGroup1.Text = "Trading Settings";
          // 
          // AdminSecMasterButton
          // 
          this.AdminSecMasterButton.ID = "AdminSecMasterButton";
          this.AdminSecMasterButton.SmallImage = ((System.Drawing.Image)(resources.GetObject("AdminSecMasterButton.SmallImage")));
          this.AdminSecMasterButton.Text = "Security Master";
          // 
          // InventoryRibbon
          // 
          this.InventoryRibbon.Groups.Add(this.InventorySubscriberGroup);
          this.InventoryRibbon.Groups.Add(this.InventoryPublisherGroup);
          this.InventoryRibbon.Groups.Add(this.InventoryManagementGroup);
          this.InventoryRibbon.ID = "InventoryRibbon";
          this.InventoryRibbon.Text = "Inventory";
          // 
          // InventorySubscriberGroup
          // 
          this.InventorySubscriberGroup.ID = "InventorySubscriberGroup";
          this.InventorySubscriberGroup.Items.Add(this.InventorySubscriptionsButton);
          this.InventorySubscriberGroup.Items.Add(this.InventoryUploadButton);
          this.InventorySubscriberGroup.Text = "Subscriber";
          // 
          // InventorySubscriptionsButton
          // 
          this.InventorySubscriptionsButton.ID = "InventorySubscriptionsButton";
          this.InventorySubscriptionsButton.SmallImage = ((System.Drawing.Image)(resources.GetObject("InventorySubscriptionsButton.SmallImage")));
          this.InventorySubscriptionsButton.Text = " Subscriptions";
          this.InventorySubscriptionsButton.Click += new System.EventHandler(this.InventorySubscriptionsButton_Click);
          // 
          // InventoryUploadButton
          // 
          this.InventoryUploadButton.Enabled = false;
          this.InventoryUploadButton.ID = "InventoryUploadButton";
          this.InventoryUploadButton.SmallImage = ((System.Drawing.Image)(resources.GetObject("InventoryUploadButton.SmallImage")));
          this.InventoryUploadButton.Text = "Upload";
          // 
          // InventoryPublisherGroup
          // 
          this.InventoryPublisherGroup.ID = "InventoryPublisherGroup";
          this.InventoryPublisherGroup.Items.Add(this.InventoryPublicationsButton);
          this.InventoryPublisherGroup.Items.Add(this.InventoryDownloadButton);
          this.InventoryPublisherGroup.Text = "Publisher";
          // 
          // InventoryPublicationsButton
          // 
          this.InventoryPublicationsButton.Enabled = false;
          this.InventoryPublicationsButton.ID = "InventoryPublicationsButton";
          this.InventoryPublicationsButton.SmallImage = ((System.Drawing.Image)(resources.GetObject("InventoryPublicationsButton.SmallImage")));
          this.InventoryPublicationsButton.Text = "Publications";
          // 
          // InventoryDownloadButton
          // 
          this.InventoryDownloadButton.Enabled = false;
          this.InventoryDownloadButton.ID = "InventoryDownloadButton";
          this.InventoryDownloadButton.SmallImage = ((System.Drawing.Image)(resources.GetObject("InventoryDownloadButton.SmallImage")));
          this.InventoryDownloadButton.Text = "Download";
          // 
          // InventoryManagementGroup
          // 
          this.InventoryManagementGroup.ID = "InventoryManagementGroup";
          this.InventoryManagementGroup.Items.Add(this.InventoryCentralButton);
          this.InventoryManagementGroup.Items.Add(this.InventorySettingsButton);
          this.InventoryManagementGroup.Text = "Management";
          // 
          // InventoryCentralButton
          // 
          this.InventoryCentralButton.Enabled = false;
          this.InventoryCentralButton.ID = "InventoryCentralButton";
          this.InventoryCentralButton.SmallImage = ((System.Drawing.Image)(resources.GetObject("InventoryCentralButton.SmallImage")));
          this.InventoryCentralButton.Text = "Central";
          // 
          // InventorySettingsButton
          // 
          this.InventorySettingsButton.Enabled = false;
          this.InventorySettingsButton.ID = "InventorySettingsButton";
          this.InventorySettingsButton.SmallImage = ((System.Drawing.Image)(resources.GetObject("InventorySettingsButton.SmallImage")));
          this.InventorySettingsButton.Text = "Settings";
          // 
          // TradingRibbon
          // 
          this.TradingRibbon.Groups.Add(this.TradingBorrowsLoansGroup);
          this.TradingRibbon.Groups.Add(this.TradingSummaryGroup);
          this.TradingRibbon.Groups.Add(this.TradingManagementGroup);
          this.TradingRibbon.Groups.Add(this.TradingToolbarsGroup);
          this.TradingRibbon.ID = "TradingRibbon";
          this.TradingRibbon.Text = "Trading";
          // 
          // TradingBorrowsLoansGroup
          // 
          this.TradingBorrowsLoansGroup.ID = "TradingBorrowsLoansGroup";
          this.TradingBorrowsLoansGroup.Items.Add(this.TradingDeskInputButton);
          this.TradingBorrowsLoansGroup.Items.Add(this.TradingContractBlotterButton);
          this.TradingBorrowsLoansGroup.Items.Add(this.ribbonButton4);
          this.TradingBorrowsLoansGroup.Items.Add(this.TradingAdvancedBorrowsButton);
          this.TradingBorrowsLoansGroup.Text = "Borrows / Loans";
          // 
          // TradingDeskInputButton
          // 
          this.TradingDeskInputButton.ID = "TradingDeskInputButton";
          this.TradingDeskInputButton.SmallImage = ((System.Drawing.Image)(resources.GetObject("TradingDeskInputButton.SmallImage")));
          this.TradingDeskInputButton.Text = "Desk Input";
          this.TradingDeskInputButton.Click += new System.EventHandler(this.TradingDeskInputButton_Click);
          // 
          // TradingContractBlotterButton
          // 
          this.TradingContractBlotterButton.ID = "TradingContractBlotterButton";
          this.TradingContractBlotterButton.SmallImage = ((System.Drawing.Image)(resources.GetObject("TradingContractBlotterButton.SmallImage")));
          this.TradingContractBlotterButton.Text = "Contract Blotter";
          this.TradingContractBlotterButton.Click += new System.EventHandler(this.TradingContractBlotterButton_Click);
          // 
          // ribbonButton4
          // 
          this.ribbonButton4.Enabled = false;
          this.ribbonButton4.ID = "ribbonButton4";
          this.ribbonButton4.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton4.SmallImage")));
          this.ribbonButton4.Text = "Advanced Loans";
          // 
          // TradingAdvancedBorrowsButton
          // 
          this.TradingAdvancedBorrowsButton.Enabled = false;
          this.TradingAdvancedBorrowsButton.ID = "TradingAdvancedBorrowsButton";
          this.TradingAdvancedBorrowsButton.SmallImage = ((System.Drawing.Image)(resources.GetObject("TradingAdvancedBorrowsButton.SmallImage")));
          this.TradingAdvancedBorrowsButton.Text = "Advanced Borrows";
          this.TradingAdvancedBorrowsButton.Click += new System.EventHandler(this.TradingAdvancedBorrowsButton_Click);
          // 
          // TradingSummaryGroup
          // 
          this.TradingSummaryGroup.ID = "TradingSummaryGroup";
          this.TradingSummaryGroup.Items.Add(this.TradingBoxSummaryButton);
          this.TradingSummaryGroup.Items.Add(this.TradingContractSummaryButton);
          this.TradingSummaryGroup.Text = "Summary";
          // 
          // TradingBoxSummaryButton
          // 
          this.TradingBoxSummaryButton.ID = "TradingBoxSummaryButton";
          this.TradingBoxSummaryButton.SmallImage = ((System.Drawing.Image)(resources.GetObject("TradingBoxSummaryButton.SmallImage")));
          this.TradingBoxSummaryButton.Text = "Box Summary";
          this.TradingBoxSummaryButton.Click += new System.EventHandler(this.TradingBoxSummaryButton_Click);
          // 
          // TradingContractSummaryButton
          // 
          this.TradingContractSummaryButton.ID = "TradingContractSummaryButton";
          this.TradingContractSummaryButton.SmallImage = ((System.Drawing.Image)(resources.GetObject("TradingContractSummaryButton.SmallImage")));
          this.TradingContractSummaryButton.Text = "Contract Summary";
          this.TradingContractSummaryButton.Click += new System.EventHandler(this.TradingContractSummaryButton_Click);
          // 
          // TradingManagementGroup
          // 
          this.TradingManagementGroup.ID = "TradingManagementGroup";
          this.TradingManagementGroup.Items.Add(this.ribbonButton2);
          this.TradingManagementGroup.Items.Add(this.ribbonButton3);
          this.TradingManagementGroup.Items.Add(this.TradingSettlementActivityButton);
          this.TradingManagementGroup.Text = "Management";
          // 
          // ribbonButton2
          // 
          this.ribbonButton2.Enabled = false;
          this.ribbonButton2.ID = "ribbonButton2";
          this.ribbonButton2.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton2.SmallImage")));
          this.ribbonButton2.Text = "Recall Management";
          // 
          // ribbonButton3
          // 
          this.ribbonButton3.Enabled = false;
          this.ribbonButton3.ID = "ribbonButton3";
          this.ribbonButton3.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton3.SmallImage")));
          this.ribbonButton3.Text = "Return Management";
          // 
          // TradingSettlementActivityButton
          // 
          this.TradingSettlementActivityButton.ID = "TradingSettlementActivityButton";
          this.TradingSettlementActivityButton.SmallImage = ((System.Drawing.Image)(resources.GetObject("TradingSettlementActivityButton.SmallImage")));
          this.TradingSettlementActivityButton.Text = "Settlement Activity";
          this.TradingSettlementActivityButton.Click += new System.EventHandler(this.TradingSettlementActivityButton_Click);
          // 
          // TradingToolbarsGroup
          // 
          this.TradingToolbarsGroup.ID = "TradingToolbarsGroup";
          this.TradingToolbarsGroup.Items.Add(this.TradingToolBarAvailabilityForm);
          this.TradingToolbarsGroup.Items.Add(this.ribbonButton1);
          this.TradingToolbarsGroup.Text = "Toolbars";
          // 
          // TradingToolBarAvailabilityForm
          // 
          this.TradingToolBarAvailabilityForm.Enabled = false;
          this.TradingToolBarAvailabilityForm.ID = "TradingToolBarAvailabilityForm";
          this.TradingToolBarAvailabilityForm.SmallImage = ((System.Drawing.Image)(resources.GetObject("TradingToolBarAvailabilityForm.SmallImage")));
          this.TradingToolBarAvailabilityForm.Text = "Availability";
          this.TradingToolBarAvailabilityForm.Click += new System.EventHandler(this.TradingToolBarAvailabilityForm_Click);
          // 
          // ribbonButton1
          // 
          this.ribbonButton1.Enabled = false;
          this.ribbonButton1.ID = "ribbonButton1";
          this.ribbonButton1.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton1.SmallImage")));
          this.ribbonButton1.Text = "Needs";
          // 
          // AnalysisRibbon
          // 
          this.AnalysisRibbon.Enabled = false;
          this.AnalysisRibbon.Groups.Add(this.ribbonGroup3);
          this.AnalysisRibbon.ID = "AnalysisRibbon";
          this.AnalysisRibbon.Text = "Analysis";
          // 
          // ribbonGroup3
          // 
          this.ribbonGroup3.ID = "ribbonGroup3";
          this.ribbonGroup3.Text = "Group";
          // 
          // ExitButton
          // 
          this.ExitButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
          this.ExitButton.BackgroundImage = global::CentralClient.Properties.Resources.Bar;
          this.ExitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
          this.ExitButton.FlatAppearance.BorderSize = 0;
          this.ExitButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
          this.ExitButton.Image = ((System.Drawing.Image)(resources.GetObject("ExitButton.Image")));
          this.ExitButton.Location = new System.Drawing.Point(1536, -1);
          this.ExitButton.Name = "ExitButton";
          this.ExitButton.Size = new System.Drawing.Size(21, 20);
          this.ExitButton.TabIndex = 3;
          this.ExitButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
          this.ExitButton.UseVisualStyleBackColor = true;
          this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
          // 
          // ShellAppBar
          // 
          this.ShellAppBar.AllowedDragDockingEdges = LogicNP.ShellObjects.DragDockingEdges.Top;
          this.ShellAppBar.AllowResize = true;
          this.ShellAppBar.DockingEdge = LogicNP.ShellObjects.DockingEdges.Top;
          this.ShellAppBar.VAnchor = LogicNP.ShellObjects.VAnchor.VAnchorTop;
          this.ShellAppBar.DockingEdgeChanged += new System.EventHandler(this.ShellAppBar_DockingEdgeChanged);
          this.ShellAppBar.HostForm = this;
          // 
          // ErrorMessageButton
          // 
          this.ErrorMessageButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
          this.ErrorMessageButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
          this.ErrorMessageButton.FlatAppearance.BorderSize = 0;
          this.ErrorMessageButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
          this.ErrorMessageButton.Image = ((System.Drawing.Image)(resources.GetObject("ErrorMessageButton.Image")));
          this.ErrorMessageButton.Location = new System.Drawing.Point(1536, 23);
          this.ErrorMessageButton.Name = "ErrorMessageButton";
          this.ErrorMessageButton.Size = new System.Drawing.Size(21, 21);
          this.ErrorMessageButton.TabIndex = 4;
          this.ErrorMessageButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
          this.ErrorMessageButton.UseVisualStyleBackColor = false;
          this.ErrorMessageButton.Click += new System.EventHandler(this.ErrorMessageButton_Click);
          // 
          // CountLabel
          // 
          this.CountLabel.Anchor = System.Windows.Forms.AnchorStyles.Right;
          this.CountLabel.AutoSize = true;
          this.CountLabel.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
          this.CountLabel.ForeColor = System.Drawing.Color.Red;
          this.CountLabel.Location = new System.Drawing.Point(1530, 31);
          this.CountLabel.Name = "CountLabel";
          this.CountLabel.Size = new System.Drawing.Size(0, 13);
          this.CountLabel.TabIndex = 5;
          this.CountLabel.Tag = null;
          this.CountLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
          this.CountLabel.TextDetached = true;
          // 
          // CountTextBox
          // 
          this.CountTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
          this.CountTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(70)))), ((int)(((byte)(70)))));
          this.CountTextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
          this.CountTextBox.DisabledForeColor = System.Drawing.Color.LavenderBlush;
          this.CountTextBox.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
          this.CountTextBox.ForeColor = System.Drawing.Color.Red;
          this.CountTextBox.Location = new System.Drawing.Point(1469, 26);
          this.CountTextBox.Name = "CountTextBox";
          this.CountTextBox.Size = new System.Drawing.Size(64, 14);
          this.CountTextBox.TabIndex = 6;
          this.CountTextBox.Tag = null;
          this.CountTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
          this.CountTextBox.TextDetached = true;
          this.CountTextBox.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
          // 
          // MainForm
          // 
          this.AutoScaleBaseSize = new System.Drawing.Size(6, 14);
          this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
          this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(70)))), ((int)(((byte)(70)))));
          this.CancelButton = this.ExitButton;
          this.ClientSize = new System.Drawing.Size(1561, 141);
          this.ControlBox = false;
          this.Controls.Add(this.CountTextBox);
          this.Controls.Add(this.CountLabel);
          this.Controls.Add(this.ErrorMessageButton);
          this.Controls.Add(this.ExitButton);
          this.Controls.Add(this.MainRibbon);
          this.DoubleBuffered = true;
          this.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
          this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
          this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
          this.Name = "MainForm";
          this.Padding = new System.Windows.Forms.Padding(1);
          this.ShowIcon = false;
          this.Text = "Loan Star";
          this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
          this.Load += new System.EventHandler(this.MainForm_Load);
          ((System.ComponentModel.ISupportInitialize)(this.MainCommandHolder)).EndInit();
          ((System.ComponentModel.ISupportInitialize)(this.MainRibbon)).EndInit();
          ((System.ComponentModel.ISupportInitialize)(this.ShellAppBar)).EndInit();
          ((System.ComponentModel.ISupportInitialize)(this.CountLabel)).EndInit();
          ((System.ComponentModel.ISupportInitialize)(this.CountTextBox)).EndInit();
          this.ResumeLayout(false);
          this.PerformLayout();

        }

        #endregion

        private C1.Win.C1Command.C1NavBar c1NavBar1;
        private C1.Win.C1Command.C1NavBarPanel c1NavBarPanel1;
        private System.Windows.Forms.Panel panel1;
        private C1.Win.C1Input.C1Button c1Button1;
    }
}